#include <string>
#include <iostream>
#include "MemberOrder.h"

using namespace std;

// Solution of TODO 3.1
MemberOrder::MemberOrder(const string& orderID, const string& name, OrderType type, int capacity) : OrdinaryOrder(orderID, name, type, capacity), rewardPoints(0) {
    std::cout << "create " << getCollectionID() << ": MemberOrder constructor" << std::endl;
}

float MemberOrder::getPoints() const {
    return rewardPoints;
}

// Solution of TODO 3.2
void MemberOrder::insert(int productID) {
    int ret = ProductCollection::insert(productID);
    
    if(!ret) {
        rewardPoints += 0.5;
    }
    return ;
}

// Solution of TODO 3.2
void MemberOrder::remove(int productID) {
    int ret = ProductCollection::remove(productID);
    
    if(!ret) {
        rewardPoints -= 0.5;
    }
    return ;
}

// Solution of TODO 3.3
void MemberOrder::addFromOrder(const OrdinaryOrder* anotherOrder) {
    int ret = OrdinaryOrder::addFromOrder(anotherOrder);

    if (!ret) {
        rewardPoints += 0.5 * anotherOrder->getSize();
    }
    return ;
}