#include <string>
#include <iostream>
#include "OrdinaryOrder.h"


using namespace std;

// Solution of TODO 2.1
OrdinaryOrder::OrdinaryOrder(const string& collectionID, const string& name, OrderType type, int capacity) : ProductCollection(collectionID, capacity), name(name), type(type) {
    std::cout << "create " << getCollectionID() << ": OrdinaryOrder constructor" << std::endl;
}

// Solution of TODO 2.2
int OrdinaryOrder::addFromOrder(const OrdinaryOrder* anotherOrder) {
    if (getCapacity() < getSize() + anotherOrder->getSize()) {
        return 1;
    };

    for (int i = 0 ; i < anotherOrder->getSize(); i++) {
        insert(anotherOrder->readProduct(i));
    }

    return 0;
}