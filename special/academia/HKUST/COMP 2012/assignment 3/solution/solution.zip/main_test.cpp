#include <iostream>
#include <vector>
using namespace std;

#include "animal.h"
#include "bst.h"
#include "adoptionCenter.h"
#include "randomAnimalGenerator.h"

void printVaccineTable(const VaccinationStatus& v) {
    unsigned int sumStringChars(const string& str);
    for (unsigned int i=0; i<VACCINE_TABLE_SIZE; ++i) {
        cout << "[" << i << "]: " << v.vaccineHashTable[i];
        if (v.vaccineHashTable[i].length() > 0)
            cout << " (" << sumStringChars(v.vaccineHashTable[i]) % VACCINE_TABLE_SIZE << ")";
        cout << endl;
    }
}

void test1() {
    VaccinationStatus v{};
    cout << "Empty Vaccine hash table count: " << v.numVaccines << endl;
}

void hiddentest1() {
    VaccinationStatus v{};
    printVaccineTable(v);
}

/***********************************************************************/

void addVaccines(VaccinationStatus& v, const vector<string>& vaccines) {
    for (string vac : vaccines)
        v.addVaccine(vac);
}

void test2() {
    VaccinationStatus v{};
    addVaccines(v, {"Rabies"});
    printVaccineTable(v);
}

void test3() {
    VaccinationStatus v{};
    addVaccines(v, {"Rabies", "FPV", "FCV"});
    printVaccineTable(v);
}

void test4() {
    VaccinationStatus v{};
    addVaccines(v, {"Rabies", "FPV", "FCV", "FHV", "FeLV"});
    printVaccineTable(v);
}

void test5() {
    VaccinationStatus v{};
    addVaccines(v, {"Rabies", "FPV", "FCV", "FHV", "FeLV", "FIV", "Chlamydia felis"});
    printVaccineTable(v);
}

void test6() {
    VaccinationStatus v{};
    addVaccines(v, {"Rabies", "FPV", "FCV", "FHV", "FeLV", "FIV", "Chlamydia felis", "Bordetella bronchiseptica", "Giardia"});
    printVaccineTable(v);
}

void hiddentest2() {
    VaccinationStatus v{};
    addVaccines(v, {"Rabies", "FPV", "FCV", "FIV", "Chlamydia felis", "Bordetella bronchiseptica", "Giardia", "Canine Distemper", "Canine Parvovirus", "CAV-2"});
    printVaccineTable(v);
}

void hiddentest3() {
    VaccinationStatus v{};
    addVaccines(v, {"Rabies", "FPV", "FCV", "FIV", "Chlamydia felis", "Bordetella bronchiseptica", "Giardia", "Canine Distemper", "Canine Parvovirus", "CAV-2", "CAV-3"});
    printVaccineTable(v);
}

void hiddentest4() {
    VaccinationStatus v{};
    addVaccines(v, {"Rabies", "FPV", "FCV", "FIV", "Chlamydia felis", "Bordetella bronchiseptica", "Giardia", "Canine Distemper", "Canine Parvovirus", "CAV-2", "Canine Distemper"});
    printVaccineTable(v);
}

void hiddentest5() {
    VaccinationStatus v{};
    addVaccines(v, {"Test Vaccine E", "Test Vaccine EE", "Test Vaccine EEE", "Test Vaccine EEEE", "Test Vaccine EEEEE", "Test Vaccine EEEEEE", "Test Vaccine EEEEEEE", "Test Vaccine EEEEEEEE", "Test Vaccine EEEEEEEEE", "Test Vaccine EEEEEEEEEE", "Test Vaccine EEEEEEEEEEE"});
    printVaccineTable(v);
}

void hiddentest6() {
    VaccinationStatus v{};
    addVaccines(v, {"Test Vaccine E", "Test Vaccine EE", "Test Vaccine EEE", "Test Vaccine EE"});
    printVaccineTable(v);
}

/***********************************************************************/

void test7() {
    VaccinationStatus v{};
    addVaccines(v, {"Rabies", "FPV", "FCV", "FHV", "FeLV", "FIV", "Chlamydia felis", "Bordetella bronchiseptica", "Giardia"});
    cout << "Contains vaccine FPV: " << v.hasVaccine("FPV") << endl; 
}

void test8() {
    VaccinationStatus v{};
    addVaccines(v, {"Rabies", "FPV", "FCV", "FHV", "FeLV", "FIV", "Chlamydia felis", "Bordetella bronchiseptica", "Giardia"});
    cout << "Contains vaccine Giardia: " << v.hasVaccine("Giardia") << endl; 
}

void hiddentest7() {
    VaccinationStatus v{};
    addVaccines(v, {"Rabies", "FPV", "FCV", "FIV", "Chlamydia felis", "Bordetella bronchiseptica", "Giardia", "Canine Distemper", "Canine Parvovirus", "CAV-2", "CAV-3"});
    cout << "Contains vaccine CAV-3: " << v.hasVaccine("CAV-3") << endl; 
}

void hiddentest8() {
    VaccinationStatus v{};
    addVaccines(v, {"Rabies", "FPV", "FCV", "FHV", "FeLV", "FIV", "Chlamydia felis", "Bordetella bronchiseptica", "Giardia"});
    cout << "Contains vaccine Canine Distemper: " << v.hasVaccine("Canine Distemper") << endl; 
}

/***********************************************************************/

Filter makeFilter(const string& s, const string& h, const vector<string>& v) {
    Filter f;
    f.speciesFilter = s;
    f.healthFilter = h;
    for (unsigned int i=0; i<v.size(); ++i)
        f.vaccineFilter[i] = v[i];
    return f;
}

Animal testAnimal = {
    0,
    Species{"Cat", "British Shorthair"},
    20,
    HealthCondition{"Very poor", 800},
    []() -> VaccinationStatus {
        VaccinationStatus v{};
        addVaccines(v, {"FPV", "FCV", "FHV"});
        return v;
    }(),
};

void test9() {
    Filter f = makeFilter(
        "cat short",
        "Poor",
        {"FCV", "FPV"}
    );
    cout << "Animal match: " << f.match(testAnimal) << endl;
}

void test10() {
    Filter f = makeFilter(
        "dog",
        "",
        {}
    );
    cout << "Animal match: " << f.match(testAnimal) << endl;
}

void test11() {
    Filter f = makeFilter(
        "cat",
        "Poor",
        {"FPV", "Rabies"}
    );
    cout << "Animal match: " << f.match(testAnimal) << endl;
}

Animal hiddenTestAnimal = {
    1,
    Species{"Bird", "Green-Cheeked Conure"},
    5,
    HealthCondition{"Healthy", 0},
};

void hiddentest9() {
    Filter f = makeFilter(
        "Green bird",
        "healthy",
        {}
    );
    cout << "Animal match: " << f.match(hiddenTestAnimal) << endl;
}

void hiddentest10() {
    Filter f = makeFilter(
        "",
        "h x",
        {}
    );
    cout << "Animal match: " << f.match(hiddenTestAnimal) << endl;
}

void hiddentest11() {
    Filter f = makeFilter(
        "Conure",
        "",
        {"Psittacosis"}
    );
    cout << "Animal match: " << f.match(hiddenTestAnimal) << endl;
}

/***********************************************************************/

void test12() {
    const int NUM_NODES = 4;
    AnimalLLnode* nodes[NUM_NODES];
    for (int i=0; i<NUM_NODES; ++i)
        nodes[i] = new AnimalLLnode(createRandomAnimal(), i == 0 ? nullptr : nodes[i-1]);
    
    unsigned int ignoreCount = 0;
    unsigned int displayCount = 4;
    nodes[NUM_NODES-1]->print(ignoreCount, displayCount, makeFilter("", "", {}));
    
    for (int i=0; i<NUM_NODES; ++i) {
        delete nodes[i]->animal;
        delete nodes[i];
    }
}

void test13() {
    const int NUM_NODES = 10;
    AnimalLLnode* nodes[NUM_NODES];
    for (int i=0; i<NUM_NODES; ++i)
        nodes[i] = new AnimalLLnode(createRandomAnimal(), i == 0 ? nullptr : nodes[i-1]);
    
    unsigned int ignoreCount = 2;
    unsigned int displayCount = 5;
    nodes[NUM_NODES-1]->print(ignoreCount, displayCount, makeFilter("", "", {}));
    
    for (int i=0; i<NUM_NODES; ++i) {
        delete nodes[i]->animal;
        delete nodes[i];
    }
}

void test14() {
    const int NUM_NODES = 10;
    AnimalLLnode* nodes[NUM_NODES];
    for (int i=0; i<NUM_NODES; ++i)
        nodes[i] = new AnimalLLnode(createRandomAnimal(), i == 0 ? nullptr : nodes[i-1]);
    
    unsigned int ignoreCount = 0;
    unsigned int displayCount = 10;
    nodes[NUM_NODES-1]->print(ignoreCount, displayCount, makeFilter("a", "", {}));
    
    for (int i=0; i<NUM_NODES; ++i) {
        delete nodes[i]->animal;
        delete nodes[i];
    }
}

void hiddentest12() {
    const int NUM_NODES = 10;
    AnimalLLnode* nodes[NUM_NODES];
    for (int i=0; i<NUM_NODES; ++i)
        nodes[i] = new AnimalLLnode(createRandomAnimal(), i == 0 ? nullptr : nodes[i-1]);
    
    unsigned int ignoreCount = 6;
    unsigned int displayCount = 4;
    nodes[NUM_NODES-1]->print(ignoreCount, displayCount, makeFilter("", "", {}));
    
    for (int i=0; i<NUM_NODES; ++i) {
        delete nodes[i]->animal;
        delete nodes[i];
    }
}

void hiddentest13() {
    const int NUM_NODES = 30;
    AnimalLLnode* nodes[NUM_NODES];
    for (int i=0; i<NUM_NODES; ++i)
        nodes[i] = new AnimalLLnode(createRandomAnimal(), i == 0 ? nullptr : nodes[i-1]);
    
    unsigned int ignoreCount = 0;
    unsigned int displayCount = 20;
    nodes[NUM_NODES-1]->print(ignoreCount, displayCount, makeFilter("", "poor", {}));
    
    for (int i=0; i<NUM_NODES; ++i) {
        delete nodes[i]->animal;
        delete nodes[i];
    }
}

void hiddentest14() {
    const int NUM_NODES = 40;
    AnimalLLnode* nodes[NUM_NODES];
    for (int i=0; i<NUM_NODES; ++i)
        nodes[i] = new AnimalLLnode(createRandomAnimal(), i == 0 ? nullptr : nodes[i-1]);
    
    unsigned int ignoreCount = 0;
    unsigned int displayCount = 20;
    nodes[NUM_NODES-1]->print(ignoreCount, displayCount, makeFilter("", "Healthy", {"PBFD"}));
    
    for (int i=0; i<NUM_NODES; ++i) {
        delete nodes[i]->animal;
        delete nodes[i];
    }
}

/***********************************************************************/

int dummyAnimalComparator(const Animal* a, const Animal* b) {
    return (static_cast<int>(a->getID()) % 100) - (static_cast<int>(b->getID()) % 100);
}

void test15() {
    Animal* animal = createRandomAnimal();
    BSTnode bstNode {animal, dummyAnimalComparator};

    AnimalLLnode* head = bstNode.head;
    unsigned int ignoreCount = 0;
    unsigned int displayCount = 1;
    cout << "Displaying linked list nodes manually: " << endl;
    do {
        head->animal->display(ignoreCount, displayCount);
        head = head->next;
    } while (head);

    delete animal;
}

void hiddentest15() {
    const int NUM_NODES = 4;
    AnimalLLnode* nodes[NUM_NODES];
    for (int i=0; i<NUM_NODES; ++i)
        nodes[i] = new AnimalLLnode(createRandomAnimal(), i == 0 ? nullptr : nodes[i-1]);
    
    Animal* animal = createRandomAnimal();
    BSTnode bstNode {animal, dummyAnimalComparator};
    bstNode.head->next = nodes[NUM_NODES-1];

    AnimalLLnode* head = bstNode.head;
    unsigned int ignoreCount = 0;
    unsigned int displayCount = 5;
    cout << "Displaying linked list nodes manually: " << endl;
    do {
        head->animal->display(ignoreCount, displayCount);
        head = head->next;
    } while (head);

    delete animal;
    for (int i=0; i<NUM_NODES; ++i) {
        delete nodes[i]->animal;
    }
}

/***********************************************************************/

void test16() {
    const int NUM_ANIMALS = 5;
    Animal* animals[NUM_ANIMALS] {nullptr};
    for (int i=0; i<NUM_ANIMALS; ++i)
        animals[i] = createRandomAnimal();
    BSTnode bstNode {animals[0], dummyAnimalComparator};
    for (int i=1; i<NUM_ANIMALS; ++i)
        bstNode.addAnimal(animals[i]);
    
    AnimalLLnode* head = bstNode.head;
    unsigned int ignoreCount = 0;
    unsigned int displayCount = NUM_ANIMALS;
    cout << "Displaying linked list nodes manually: " << endl;
    do {
        head->animal->display(ignoreCount, displayCount);
        head = head->next;
    } while (head);

    for (int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
}

void test17() {
    const int NUM_ANIMALS = 10;
    Animal* animals[NUM_ANIMALS] {nullptr};
    int index[NUM_ANIMALS] = {4, 3, 8, 9, 5, 1, 2, 7, 6, 0};
    for (int i=0; i<NUM_ANIMALS; ++i)
        animals[index[i]] = createRandomAnimal();
    BSTnode bstNode {animals[0], dummyAnimalComparator};
    for (int i=1; i<NUM_ANIMALS; ++i) {
        cout << "Adding animal with ID " << animals[i]->getID() << endl;
        bstNode.addAnimal(animals[i]);
    }
    
    AnimalLLnode* head = bstNode.head;
    unsigned int ignoreCount = 0;
    unsigned int displayCount = NUM_ANIMALS;
    cout << "Displaying linked list nodes manually: " << endl;
    do {
        head->animal->display(ignoreCount, displayCount);
        head = head->next;
    } while (head);

    for (int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
}

void hiddentest16() {
    const int NUM_ANIMALS = 10;
    Animal* animals[NUM_ANIMALS] {nullptr};
    for (int i=0; i<NUM_ANIMALS; ++i)
        animals[i] = createRandomAnimal();
    BSTnode bstNode {animals[0], dummyAnimalComparator};
    for (int i=1; i<NUM_ANIMALS; ++i)
        bstNode.addAnimal(animals[i]);
    
    unsigned int ignoreCount = 0;
    unsigned int displayCount = NUM_ANIMALS;
    bstNode.head->print(ignoreCount, displayCount, makeFilter("", "", {}));

    for (int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
}

void hiddentest17() {
    const int NUM_ANIMALS = 10;
    Animal* animals[NUM_ANIMALS] {nullptr};
    int index[NUM_ANIMALS] = {9, 8, 7, 6, 5, 4, 3, 2, 1, 0};
    for (int i=0; i<NUM_ANIMALS; ++i)
        animals[index[i]] = createRandomAnimal();
    BSTnode bstNode {animals[0], dummyAnimalComparator};
    for (int i=1; i<NUM_ANIMALS; ++i) {
        cout << "Adding animal with ID " << animals[i]->getID() << endl;
        bstNode.addAnimal(animals[i]);
    }
    
    unsigned int ignoreCount = 0;
    unsigned int displayCount = NUM_ANIMALS;
    bstNode.head->print(ignoreCount, displayCount, makeFilter("", "", {}));

    for (int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
}

/***********************************************************************/

void test18() {
    const int NUM_ANIMALS = 10;
    Animal* animals[NUM_ANIMALS] {nullptr};
    for (int i=0; i<NUM_ANIMALS; ++i)
        animals[i] = createRandomAnimal();
    BSTnode bstNode {animals[0], dummyAnimalComparator};
    for (int i=1; i<NUM_ANIMALS; ++i)
        bstNode.addAnimal(animals[i]);

    bstNode.removeAnimal(animals[5]);

    AnimalLLnode* head = bstNode.head;
    unsigned int ignoreCount = 0;
    unsigned int displayCount = 9;
    cout << "Displaying linked list nodes manually: " << endl;
    do {
        head->animal->display(ignoreCount, displayCount);
        head = head->next;
    } while (head);

    for (int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
}

void test19() {
    const int NUM_ANIMALS = 10;
    Animal* animals[NUM_ANIMALS] {nullptr};
    for (int i=0; i<NUM_ANIMALS; ++i)
        animals[i] = createRandomAnimal();
    BSTnode bstNode {animals[0], dummyAnimalComparator};
    for (int i=1; i<NUM_ANIMALS; ++i)
        bstNode.addAnimal(animals[i]);

    bstNode.removeAnimal(animals[7]);
    bstNode.removeAnimal(animals[2]);
    bstNode.addAnimal(animals[7]);

    AnimalLLnode* head = bstNode.head;
    unsigned int ignoreCount = 0;
    unsigned int displayCount = 9;
    cout << "Displaying linked list nodes manually: " << endl;
    do {
        head->animal->display(ignoreCount, displayCount);
        head = head->next;
    } while (head);

    for (int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
}

void test20() {
    const int NUM_ANIMALS = 3;
    Animal* animals[NUM_ANIMALS] {nullptr};
    for (int i=0; i<NUM_ANIMALS; ++i)
        animals[i] = createRandomAnimal();
    BSTnode bstNode {animals[0], dummyAnimalComparator};
    for (int i=1; i<NUM_ANIMALS; ++i)
        bstNode.addAnimal(animals[i]);
    for (int i=0; i<NUM_ANIMALS; ++i)
        bstNode.removeAnimal(animals[i]);

    cout << "Empty BSTnode's head is nullptr: " << (bstNode.head == nullptr) << endl;

    for (int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
}

void hiddentest18() {
    const int NUM_ANIMALS = 11;
    Animal* animals[NUM_ANIMALS] {nullptr};
    for (int i=0; i<NUM_ANIMALS; ++i)
        animals[i] = createRandomAnimal();
    BSTnode bstNode {animals[0], dummyAnimalComparator};
    for (int i=1; i<NUM_ANIMALS-1; ++i)
        bstNode.addAnimal(animals[i]);

    bstNode.removeAnimal(animals[10]);

    AnimalLLnode* head = bstNode.head;
    unsigned int ignoreCount = 0;
    unsigned int displayCount = 10;
    cout << "Displaying linked list nodes manually: " << endl;
    do {
        head->animal->display(ignoreCount, displayCount);
        head = head->next;
    } while (head);

    for (int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
}

void hiddentest19() {
    const int NUM_ANIMALS = 10;
    Animal* animals[NUM_ANIMALS] {nullptr};
    for (int i=0; i<NUM_ANIMALS; ++i)
        animals[i] = createRandomAnimal();
    BSTnode bstNode {animals[0], dummyAnimalComparator};
    for (int i=1; i<NUM_ANIMALS; ++i)
        bstNode.addAnimal(animals[i]);

    bstNode.removeAnimal(animals[9]);
    bstNode.removeAnimal(animals[8]);
    bstNode.removeAnimal(animals[4]);
    bstNode.addAnimal(animals[9]);

    AnimalLLnode* head = bstNode.head;
    unsigned int ignoreCount = 0;
    unsigned int displayCount = 8;
    cout << "Displaying linked list nodes manually: " << endl;
    do {
        head->animal->display(ignoreCount, displayCount);
        head = head->next;
    } while (head);

    for (int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
}

void hiddentest20() {
    const int NUM_ANIMALS = 5;
    Animal* animals[NUM_ANIMALS] {nullptr};
    for (int i=0; i<NUM_ANIMALS; ++i)
        animals[i] = createRandomAnimal();
    BSTnode bstNode {animals[0], dummyAnimalComparator};
    for (int i=1; i<3; ++i)
        bstNode.addAnimal(animals[i]);
    for (int i=0; i<NUM_ANIMALS; ++i)
        bstNode.removeAnimal(animals[i]);

    cout << "Empty BSTnode's head is nullptr: " << (bstNode.head == nullptr) << endl;

    for (int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
}

/***********************************************************************/

void printNode(const AnimalLLnode* const node) {
    cout << node->animal->getID();
    if (node->next) {
        cout << " -> ";
        printNode(node->next);
    }
    else
        cout << endl;
}

void printTest(const BST& bst, unsigned int depth = 0) {
    if (bst.isEmpty())
        return;
    printTest(bst.root->right, depth+1);
    for (unsigned int j = 0; j < depth; j++)
        cout << '\t';
    printNode(bst.root->head);
    printTest(bst.root->left, depth+1);
}

Animal* createRandomAnimalWithID(unsigned int id) {
    extern unsigned int animalID;
    animalID = id;
    return createRandomAnimal();
}

void test21() {
    BST bst{dummyAnimalComparator};
    const int NUM_ANIMALS = 10;
    Animal* animals[NUM_ANIMALS] {nullptr};
    int index[NUM_ANIMALS] = {4, 3, 8, 9, 5, 1, 2, 7, 6, 0};
    for (unsigned int i=0; i<NUM_ANIMALS; ++i) {
        animals[i] = createRandomAnimalWithID(index[i]);
        bst.insert(animals[i]);
    }
    printTest(bst);
    for (unsigned int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
}

void test22() {
    BST bst{dummyAnimalComparator};
    const int NUM_ANIMALS = 10;
    Animal* animals[NUM_ANIMALS] {nullptr};
    int index[NUM_ANIMALS] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
    for (unsigned int i=0; i<NUM_ANIMALS; ++i) {
        animals[i] = createRandomAnimalWithID(index[i]);
        bst.insert(animals[i]);
    }
    printTest(bst);
    for (unsigned int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
}

void test23() {
    BST bst{dummyAnimalComparator};
    const int NUM_ANIMALS = 10;
    Animal* animals[NUM_ANIMALS * 2];
    int index[NUM_ANIMALS] = {4, 3, 8, 9, 5, 1, 2, 7, 6, 0};
    for (unsigned int i=0; i<NUM_ANIMALS; ++i) {
        animals[i] = createRandomAnimalWithID(index[i]);
        bst.insert(animals[i]);
    }
    for (unsigned int i=10; i<15; ++i) {
        animals[i] = createRandomAnimalWithID(i + 91);
        bst.insert(animals[i]);
    }
    for (unsigned int i=15; i<20; ++i) {
        animals[i] = createRandomAnimalWithID(i * 2 + 171);
        bst.insert(animals[i]);
    }
    printTest(bst);
    for (unsigned int i=0; i<NUM_ANIMALS*2; ++i)
        delete animals[i];
}

vector<unsigned int> generateSequence(const unsigned int size, const unsigned int N) {
    unsigned int* all = new unsigned int[N];
    for (unsigned int i=0; i<N; ++i) all[i] = i;
    for (unsigned int i=N-1; i>=1; --i) {
        extern unsigned int pa3_rand();
        unsigned int j = pa3_rand() % i;
        unsigned int temp = all[i];
        all[i] = all[j];
        all[j] = temp;
    }
    vector<unsigned int> ret {};
    for (unsigned int i=0; i<size; ++i) ret.push_back(all[i]);
    delete [] all;
    return ret;
}

void hiddentest21() {
    BST bst{dummyAnimalComparator};
    const int NUM_ANIMALS = 30;
    const vector<unsigned int> index = generateSequence(NUM_ANIMALS, 100);
    Animal* animals[NUM_ANIMALS] {nullptr};
    for (unsigned int i=0; i<NUM_ANIMALS; ++i) {
        animals[i] = createRandomAnimalWithID(index[i]);
        bst.insert(animals[i]);
    }
    printTest(bst);
    for (unsigned int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
}

void hiddentest22() {
    BST bst{dummyAnimalComparator};
    const int NUM_ANIMALS = 40;
    Animal* animals[NUM_ANIMALS] {nullptr};
    for (unsigned int i=0; i<40; ++i) {
        animals[i] = createRandomAnimalWithID(i * 25);
        bst.insert(animals[i]);
    }
    printTest(bst);
    for (unsigned int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
}

void hiddentest23() {
    BST bst{dummyAnimalComparator};
    const int NUM_ANIMALS = 100;
    const vector<unsigned int> index = generateSequence(NUM_ANIMALS, 1000);
    Animal* animals[NUM_ANIMALS] {nullptr};
    for (unsigned int i=0; i<NUM_ANIMALS; ++i) {
        animals[i] = createRandomAnimalWithID(index[i]);
        bst.insert(animals[i]);
    }
    printTest(bst);
    for (unsigned int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
}

/***********************************************************************/

void test24() {
    BST bst{dummyAnimalComparator};
    const int NUM_ANIMALS = 15;
    Animal* animals[NUM_ANIMALS] {nullptr};
    int index[NUM_ANIMALS] = {4, 3, 8, 9, 11, 5, 1, 2, 7, 10, 14, 13, 12, 6, 0};
    for (unsigned int i=0; i<NUM_ANIMALS; ++i) {
        animals[i] = createRandomAnimalWithID(index[i]);
        bst.insert(animals[i]);
    }
    cout << "Removing id " << animals[13]->getID() << endl;
    bst.remove(animals[13]);
    printTest(bst);
    for (unsigned int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
}

void test25() {
    BST bst{dummyAnimalComparator};
    const int NUM_ANIMALS = 15;
    Animal* animals[NUM_ANIMALS] {nullptr};
    int index[NUM_ANIMALS] = {4, 3, 8, 9, 11, 5, 1, 2, 7, 10, 14, 13, 12, 6, 0};
    for (unsigned int i=0; i<NUM_ANIMALS; ++i) {
        animals[i] = createRandomAnimalWithID(index[i]);
        bst.insert(animals[i]);
    }
    cout << "Removing id " << animals[11]->getID() << endl;
    bst.remove(animals[11]);
    printTest(bst);
    for (unsigned int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
}

void test26() {
    BST bst{dummyAnimalComparator};
    const int NUM_ANIMALS = 15;
    Animal* animals[NUM_ANIMALS] {nullptr};
    int index[NUM_ANIMALS] = {4, 3, 8, 9, 11, 5, 1, 2, 7, 10, 14, 13, 12, 6, 0};
    for (unsigned int i=0; i<NUM_ANIMALS; ++i) {
        animals[i] = createRandomAnimalWithID(index[i]);
        bst.insert(animals[i]);
    }
    cout << "Removing id " << animals[6]->getID() << endl;
    bst.remove(animals[6]);
    printTest(bst);
    for (unsigned int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
}

void test27() {
    BST bst{dummyAnimalComparator};
    const int NUM_ANIMALS = 15;
    Animal* animals[NUM_ANIMALS] {nullptr};
    int index[NUM_ANIMALS] = {4, 3, 8, 9, 11, 5, 1, 2, 7, 10, 14, 13, 12, 6, 0};
    for (unsigned int i=0; i<NUM_ANIMALS; ++i) {
        animals[i] = createRandomAnimalWithID(index[i]);
        bst.insert(animals[i]);
    }
    cout << "Removing id " << animals[4]->getID() << endl;
    bst.remove(animals[4]);
    printTest(bst);
    for (unsigned int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
}

void test28() {
    BST bst{dummyAnimalComparator};
    const int NUM_ANIMALS = 15;
    Animal* animals[NUM_ANIMALS] {nullptr};
    int index[NUM_ANIMALS] = {4, 3, 8, 9, 11, 5, 1, 2, 7, 10, 14, 13, 12, 6, 0};
    for (unsigned int i=0; i<NUM_ANIMALS; ++i) {
        animals[i] = createRandomAnimalWithID(index[i]);
        bst.insert(animals[i]);
    }
    const int NUM_EXTRA_ANIMALS = 5;
    Animal* extraAnimals[NUM_EXTRA_ANIMALS];
    for (unsigned int i=0; i<NUM_EXTRA_ANIMALS; ++i) {
        extraAnimals[i] = createRandomAnimalWithID(i * 3 + 101);
        bst.insert(extraAnimals[i]);
    }
    cout << "Removing id " << animals[11]->getID() << endl;
    bst.remove(animals[11]);
    printTest(bst);
    for (unsigned int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
    for (unsigned int i=0; i<NUM_EXTRA_ANIMALS; ++i)
        delete extraAnimals[i];
}

void test29() {
    BST bst{dummyAnimalComparator};
    const int NUM_ANIMALS = 15;
    Animal* animals[NUM_ANIMALS] {nullptr};
    int index[NUM_ANIMALS] = {4, 3, 8, 9, 11, 5, 1, 2, 7, 10, 14, 13, 12, 6, 0};
    for (unsigned int i=0; i<NUM_ANIMALS; ++i) {
        animals[i] = createRandomAnimalWithID(index[i]);
        bst.insert(animals[i]);
    }
    const int NUM_EXTRA_ANIMALS = 5;
    Animal* extraAnimals[NUM_EXTRA_ANIMALS];
    for (unsigned int i=0; i<NUM_EXTRA_ANIMALS; ++i) {
        extraAnimals[i] = createRandomAnimalWithID(i * 3 + 102);
        bst.insert(extraAnimals[i]);
    }
    cout << "Removing id " << animals[6]->getID() << endl;
    bst.remove(animals[6]);
    printTest(bst);
    for (unsigned int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
    for (unsigned int i=0; i<NUM_EXTRA_ANIMALS; ++i)
        delete extraAnimals[i];
}

void test30() {
    BST bst{dummyAnimalComparator};
    const int NUM_ANIMALS = 15;
    Animal* animals[NUM_ANIMALS] {nullptr};
    int index[NUM_ANIMALS] = {4, 3, 8, 9, 11, 5, 1, 2, 7, 10, 14, 13, 12, 6, 0};
    for (unsigned int i=0; i<NUM_ANIMALS; ++i) {
        animals[i] = createRandomAnimalWithID(index[i]);
        bst.insert(animals[i]);
    }
    const int NUM_EXTRA_ANIMALS = 5;
    Animal* extraAnimals[NUM_EXTRA_ANIMALS];
    for (unsigned int i=0; i<NUM_EXTRA_ANIMALS; ++i) {
        extraAnimals[i] = createRandomAnimalWithID(i * 3 + 100);
        bst.insert(extraAnimals[i]);
    }
    cout << "Removing id " << animals[4]->getID() << endl;
    bst.remove(animals[4]);
    printTest(bst);
    for (unsigned int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
    for (unsigned int i=0; i<NUM_EXTRA_ANIMALS; ++i)
        delete extraAnimals[i];
}

void hiddentest24() {
    BST bst{dummyAnimalComparator};
    const int NUM_ANIMALS = 15;
    Animal* animals[NUM_ANIMALS] {nullptr};
    int index[NUM_ANIMALS] = {4, 3, 8, 9, 11, 5, 1, 2, 7, 10, 14, 13, 12, 6, 0};
    for (unsigned int i=0; i<NUM_ANIMALS; ++i) {
        animals[i] = createRandomAnimalWithID(index[i]);
        bst.insert(animals[i]);
    }
    Animal* doesNotExist = createRandomAnimalWithID(20);
    cout << "Removing id " << doesNotExist->getID() << endl;
    bst.remove(doesNotExist);
    printTest(bst);
    for (unsigned int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
    delete doesNotExist;
}

void hiddentest25() {
    BST bst{dummyAnimalComparator};
    const int NUM_ANIMALS = 30;
    Animal* animals[NUM_ANIMALS] {nullptr};
    vector<unsigned int> index = generateSequence(NUM_ANIMALS, 100);
    for (unsigned int i=0; i<NUM_ANIMALS; ++i) {
        animals[i] = createRandomAnimalWithID(index[i]);
        bst.insert(animals[i]);
    }
    printTest(bst);
    cout << "Removing id " << animals[10]->getID() << endl;
    bst.remove(animals[10]);
    printTest(bst);
    for (unsigned int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
}

void hiddentest26() {
    BST bst{dummyAnimalComparator};
    const int NUM_ANIMALS = 40;
    Animal* animals[NUM_ANIMALS] {nullptr};
    vector<unsigned int> index = generateSequence(NUM_ANIMALS, 100);
    for (unsigned int i=0; i<NUM_ANIMALS; ++i) {
        animals[i] = createRandomAnimalWithID(index[i]);
        bst.insert(animals[i]);
    }
    printTest(bst);
    cout << "Removing id " << animals[7]->getID() << endl;
    bst.remove(animals[7]);
    cout << "Removing id " << animals[14]->getID() << endl;
    bst.remove(animals[14]);
    cout << "Removing id " << animals[28]->getID() << endl;
    bst.remove(animals[28]);
    printTest(bst);
    for (unsigned int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
}

void hiddentest27() {
    BST bst{dummyAnimalComparator};
    const int NUM_ANIMALS = 100;
    Animal* animals[NUM_ANIMALS] {nullptr};
    vector<unsigned int> index = generateSequence(NUM_ANIMALS, 1000);
    for (unsigned int i=0; i<100; ++i) {
        animals[i] = createRandomAnimalWithID(index[i]);
        bst.insert(animals[i]);
    }
    printTest(bst);
    for (unsigned int i=5; i<100; i=i+5) {
        cout << "Removing id " << animals[i]->getID() << endl;
        bst.remove(animals[i]);
    }
    printTest(bst);
    for (unsigned int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
}

void hiddentest28() {
    BST bst{dummyAnimalComparator};
    const int NUM_ANIMALS = 150;
    Animal* animals[NUM_ANIMALS] {nullptr};
    vector<unsigned int> index = generateSequence(NUM_ANIMALS, 1000);
    for (unsigned int i=0; i<100; ++i) {
        animals[i] = createRandomAnimalWithID(index[i]);
        bst.insert(animals[i]);
    }
    for (unsigned int i=5; i<100; i=i+3) {
        bst.remove(animals[i]);
    }
    for (unsigned int i=100; i<NUM_ANIMALS; ++i) {
        animals[i] = createRandomAnimalWithID(index[i]);
        bst.insert(animals[i]);
    }
    printTest(bst);
    for (unsigned int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
}

void hiddentest29() {
    BST bst{dummyAnimalComparator};
    const int NUM_ANIMALS = 150;
    Animal* animals[NUM_ANIMALS] {nullptr};
    vector<unsigned int> index = generateSequence(NUM_ANIMALS, 1000);
    for (unsigned int i=0; i<50; ++i) {
        animals[i] = createRandomAnimalWithID(index[i]);
        bst.insert(animals[i]);
    }
    for (unsigned int i=0; i<50; i=i+2) {
        bst.remove(animals[i]);
    }
    for (unsigned int i=50; i<100; ++i) {
        animals[i] = createRandomAnimalWithID(index[i]);
        bst.insert(animals[i]);
    }
    for (unsigned int i=51; i<100; i=i+2) {
        bst.remove(animals[i]);
    }
    for (unsigned int i=100; i<150; ++i) {
        animals[i] = createRandomAnimalWithID(index[i]);
        bst.insert(animals[i]);
    }
    for (unsigned int i=10; i<150; i=i+3) {
        bst.remove(animals[i]);
    }
    printTest(bst);
    for (unsigned int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
}

void hiddentest30() {
    BST bst{dummyAnimalComparator};
    const int NUM_ANIMALS = 500;
    Animal* animals[NUM_ANIMALS] {nullptr};
    vector<unsigned int> index = generateSequence(NUM_ANIMALS, 1000);
    for (unsigned int i=0; i<NUM_ANIMALS; ++i) {
        animals[i] = createRandomAnimalWithID(index[i]);
        bst.insert(animals[i]);
    }
    for (unsigned int i=0; i<NUM_ANIMALS; ++i) {
        if (i == 128) continue;
        bst.remove(animals[i]);
    }
    printTest(bst);
    for (unsigned int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
}

/***********************************************************************/

void test31() {
    BST bst{dummyAnimalComparator};
    const int NUM_ANIMALS = 15;
    Animal* animals[NUM_ANIMALS] {nullptr};
    int index[NUM_ANIMALS] = {4, 3, 8, 9, 11, 5, 1, 2, 7, 10, 14, 13, 12, 6, 0};
    for (unsigned int i=0; i<NUM_ANIMALS; ++i) {
        animals[i] = createRandomAnimalWithID(index[i]);
        bst.insert(animals[i]);
    }
    const int NUM_EXTRA_ANIMALS = 5;
    Animal* extraAnimals[NUM_EXTRA_ANIMALS];
    for (unsigned int i=0; i<NUM_EXTRA_ANIMALS; ++i) {
        extraAnimals[i] = createRandomAnimalWithID(i * 3 + 100);
        bst.insert(extraAnimals[i]);
    }
    unsigned int ignoreCount = 0;
    unsigned int displayCount = 20;
    bst.print(ignoreCount, displayCount, makeFilter("", "", {}));
    for (unsigned int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
    for (unsigned int i=0; i<NUM_EXTRA_ANIMALS; ++i)
        delete extraAnimals[i];
}

void test32() {
    BST bst{dummyAnimalComparator};
    const int NUM_ANIMALS = 15;
    Animal* animals[NUM_ANIMALS] {nullptr};
    int index[NUM_ANIMALS] = {4, 3, 8, 9, 11, 5, 1, 2, 7, 10, 14, 13, 12, 6, 0};
    for (unsigned int i=0; i<NUM_ANIMALS; ++i) {
        animals[i] = createRandomAnimalWithID(index[i]);
        bst.insert(animals[i]);
    }
    const int NUM_EXTRA_ANIMALS = 5;
    Animal* extraAnimals[NUM_EXTRA_ANIMALS];
    for (unsigned int i=0; i<NUM_EXTRA_ANIMALS; ++i) {
        extraAnimals[i] = createRandomAnimalWithID(i * 3 + 100);
        bst.insert(extraAnimals[i]);
    }
    unsigned int ignoreCount = 3;
    unsigned int displayCount = 15;
    bst.print(ignoreCount, displayCount, makeFilter("", "Healthy", {}));
    for (unsigned int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
    for (unsigned int i=0; i<NUM_EXTRA_ANIMALS; ++i)
        delete extraAnimals[i];
}

void hiddentest31() {
    BST bst{dummyAnimalComparator};
    const int NUM_ANIMALS = 30;
    Animal* animals[NUM_ANIMALS] {nullptr};
    vector<unsigned int> index = generateSequence(NUM_ANIMALS, 1000);
    for (unsigned int i=0; i<NUM_ANIMALS; ++i) {
        animals[i] = createRandomAnimalWithID(index[i]);
        bst.insert(animals[i]);
    }
    unsigned int ignoreCount = 0;
    unsigned int displayCount = 30;
    bst.print(ignoreCount, displayCount, makeFilter("", "", {}));
    for (unsigned int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
}

void hiddentest32() {
    BST bst{dummyAnimalComparator};
    const int NUM_ANIMALS = 500;
    Animal* animals[NUM_ANIMALS] {nullptr};
    vector<unsigned int> index = generateSequence(NUM_ANIMALS, 1000);
    for (unsigned int i=0; i<NUM_ANIMALS; ++i) {
        animals[i] = createRandomAnimalWithID(index[i]);
        bst.insert(animals[i]);
    }
    unsigned int ignoreCount = 10;
    unsigned int displayCount = 30;
    bst.print(ignoreCount, displayCount, makeFilter("cat", "", {"Rabies"}));
    for (unsigned int i=0; i<NUM_ANIMALS; ++i)
        delete animals[i];
}

/***********************************************************************/

void test33() {
    AdoptionCenter center;
    for (unsigned int i=0; i<20; ++i) {
        center.addAnimal(createRandomAnimal());
    }
    center.display(0, 20, makeFilter("", "", {}));
}

void test34() {
    AdoptionCenter center;
    for (unsigned int i=0; i<20; ++i) {
        center.addAnimal(createRandomAnimal());
    }
    center.display(0, 20, makeFilter("", "", {}), NAME);
}

void test35() {
    AdoptionCenter center;
    for (unsigned int i=0; i<20; ++i) {
        center.addAnimal(createRandomAnimal());
    }
    center.display(0, 20, makeFilter("", "", {}), AGE);
}

void test36() {
    AdoptionCenter center;
    for (unsigned int i=0; i<20; ++i) {
        center.addAnimal(createRandomAnimal());
    }
    center.display(0, 20, makeFilter("", "", {}), HEALTH);
}

void test37() {
    AdoptionCenter center;
    for (unsigned int i=0; i<20; ++i) {
        center.addAnimal(createRandomAnimal());
    }
    center.display(0, 20, makeFilter("", "", {}), VACCINE);
}

void hiddentest33() {
    AdoptionCenter center;
    for (unsigned int i=0; i<100; ++i) {
        center.addAnimal(createRandomAnimal());
    }
    center.display(0, 20, makeFilter("Reptiles", "", {}));
}

void hiddentest34() {
    AdoptionCenter center;
    for (unsigned int i=0; i<100; ++i) {
        center.addAnimal(createRandomAnimal());
    }
    center.display(0, 20, makeFilter("", "poor", {}), NAME);
}

void hiddentest35() {
    AdoptionCenter center;
    for (unsigned int i=0; i<250; ++i) {
        center.addAnimal(createRandomAnimal());
    }
    center.display(0, 20, makeFilter("Dog", "", {"Rabies"}), AGE);
}

/***********************************************************************/

void test38() {
    AdoptionCenter center;
    for (unsigned int i=0; i<50; ++i) {
        center.addAnimal(createRandomAnimal());
    }
    for (unsigned int i=3; i<50; i=i+7) {
        cout << "Remove ID " << i << " is successful: " << center.removeAnimal(i) << endl;
    }
}

void hiddentest36() {
    AdoptionCenter center;
    for (unsigned int i=0; i<50; ++i) {
        center.addAnimal(createRandomAnimal());
    }
    cout << "Remove ID " << 50 << " is successful: " << center.removeAnimal(50) << endl;
}

void hiddentest37() {
    AdoptionCenter center;
    for (unsigned int i=0; i<100; ++i) {
        center.addAnimal(createRandomAnimal());
    }
    for (unsigned int i=4; i<100; i=i+5) {
        center.removeAnimal(i);
    }
    for (unsigned int i=0; i<20; ++i) {
        center.addAnimal(createRandomAnimal());
    }
    center.display(0, 20, makeFilter("", "", {}));
}

void hiddentest38() {
    AdoptionCenter center;
    for (unsigned int i=0; i<100; ++i) {
        center.addAnimal(createRandomAnimal());
    }
    for (unsigned int i=6; i<100; i=i+13) {
        cout << "Remove ID " << i << " is successful: " << center.removeAnimal(i) << endl;
    }
    cout << "Remove ID " << 58 << " is successful: " << center.removeAnimal(58) << endl;
}

/***********************************************************************/

void test39() {
    AdoptionCenter center;
    for (unsigned int i=0; i<20; ++i) {
        center.addAnimal(createRandomAnimal());
    }
    center.incrementAge();
    center.display(0, 20, makeFilter("", "", {}));
}

void test40() {
    AdoptionCenter center;
    for (unsigned int i=0; i<20; ++i) {
        center.addAnimal(createRandomAnimal());
    }
    center.setAnimalHealthCondition(5, HealthCondition{"Weak", 750});
    center.display(0, 20, makeFilter("", "", {}), HEALTH);
}

void test41() {
    AdoptionCenter center;
    for (unsigned int i=0; i<20; ++i) {
        center.addAnimal(createRandomAnimal());
    }
    center.addAnimalVaccine(6, "Paramyxovirus");
    center.display(0, 20, makeFilter("", "", {}), VACCINE);
}

void test42() {
    AdoptionCenter center;
    for (unsigned int i=0; i<20; ++i) {
        center.addAnimal(createRandomAnimal());
    }
    center.setAnimalSpecialNeeds(13, "Antibacterial medicine");
    center.display(0, 20, makeFilter("", "", {}));
}

void hiddentest39() {
    AdoptionCenter center;
    for (unsigned int i=0; i<300; ++i) {
        center.addAnimal(createRandomAnimal());
    }
    for (unsigned int i=5; i<300; i=i+50) {
        center.setAnimalHealthCondition(i, HealthCondition{"Extremely critical", 990});
    }
    center.display(280, 300, makeFilter("", "", {}), HEALTH);
}

void hiddentest40() {
    AdoptionCenter center;
    for (unsigned int i=0; i<300; ++i) {
        center.addAnimal(createRandomAnimal());
    }
    for (unsigned int i=6; i<322; i=i+22) {
        center.setAnimalHealthCondition(i, HealthCondition{"Mild", 100});
    }
    center.display(235, 265, makeFilter("", "", {}), HEALTH);
}

void hiddentest41() {
    AdoptionCenter center;
    for (unsigned int i=0; i<300; ++i) {
        center.addAnimal(createRandomAnimal());
    }
    for (unsigned int i=5; i<300; i=i+5) {
        center.addAnimalVaccine(i, "Rabies");
    }
    center.display(0, 20, makeFilter("", "", {}), VACCINE);
}

void hiddentest42() {
    AdoptionCenter center;
    for (unsigned int i=0; i<300; ++i) {
        center.addAnimal(createRandomAnimal());
    }
    for (unsigned int i=10; i<300; i=i+27) {
        center.addAnimalVaccine(i, "Fictional Vaccine");
    }
    center.display(0, 40, makeFilter("", "", {"Fictional Vaccine"}), VACCINE);
    cout << "Animal ID 280's vaccines: " << endl;
    center.displayPetVaccines(280);
}

/***********************************************************************/

void centerSetup(AdoptionCenter& center) {
    for (int i=0; i<500; ++i) {
        center.addAnimal(createRandomAnimal());
    }
    for (int i=3; i<500; i += 5) {
        center.removeAnimal(i);
    }
    for (int i=500; i<700; ++i) {
        center.addAnimal(createRandomAnimal());
    }
    for (int i=507; i<700;  i+=11) {
        center.removeAnimal(i);
    }
}

void test43() {
    AdoptionCenter center;
    centerSetup(center);
    center.display(0, 20, makeFilter("cat N/A", "Healthy", {"Rabies"}));
}

void test44() {
    AdoptionCenter center;
    centerSetup(center);
    center.display(0, 20, makeFilter("", "", {"Filavac RHD AS", "Pasteurellosis", "Bordetella bronchiseptica"}));
}

void test45() {
    AdoptionCenter center;
    centerSetup(center);
    center.incrementAge();
    center.display(30, 50, makeFilter("", "", {}), AGE);
}

void test46() {
    AdoptionCenter center;
    centerSetup(center);
    center.setAnimalHealthCondition(251, HealthCondition{"Very bad", 600});
    center.setAnimalSpecialNeeds(251, "Requires intensive care");
    center.display(0, 30, makeFilter("", "", {}), NAME);
}

void test47() {
    AdoptionCenter center;
    centerSetup(center);
    center.addAnimalVaccine(24, "Avian Polyomavirus");
    center.addAnimalVaccine(24, "Marek\'s Disease");
    center.addAnimalVaccine(24, "Candidiasis");
    center.addAnimalVaccine(274, "Poxvirus");
    center.display(0, 30, makeFilter("parrot", "", {}), VACCINE);
}

void test48() {
    AdoptionCenter center;
    centerSetup(center);
    center.removeAnimal(9);
    center.setAnimalHealthCondition(14, HealthCondition{"Healthy", 0});
    center.addAnimalVaccine(14, "Iridovirus");
    center.display(0, 30, makeFilter("", "", {}));
}

void test49() {
    AdoptionCenter center;
    centerSetup(center);
    for (int i=16; i<700; i+=23) {
        extern unsigned int pa3_rand();
        switch (pa3_rand() % 4) {
            case 0:
                center.removeAnimal(i);
                break;
            case 1:
                center.setAnimalHealthCondition(i, HealthCondition{"Custom text", 500});
                break;
            case 2:
                center.addAnimalVaccine(i, "Custom vaccine");
                break;
            case 3:
                center.setAnimalSpecialNeeds(i, "Custom text");
                break;
        }
    }
    center.display(500, 550, makeFilter("", "", {}), HEALTH);
}

void test50() {
    AdoptionCenter center;
    centerSetup(center);
    for (int i=4; i<700; i+=5) {
        extern unsigned int pa3_rand();
        switch (pa3_rand() % 4) {
            case 0:
                center.removeAnimal(i);
                break;
            case 1:
                center.setAnimalHealthCondition(i, HealthCondition{"Custom text", 500});
                break;
            case 2:
                center.addAnimalVaccine(i, "Custom vaccine");
                break;
            case 3:
                center.setAnimalSpecialNeeds(i, "Custom text");
                break;
        }
    }
    center.display(200, 250, makeFilter("", "", {}), VACCINE);
}

void centerSetupHidden(AdoptionCenter& center) {
    for (int i=0; i<1000; ++i) {
        center.addAnimal(createRandomAnimal());
    }
    for (int i=7; i<1000; i += 11) {
        center.removeAnimal(i);
    }
    for (int i=1000; i<2000; ++i) {
        center.addAnimal(createRandomAnimal());
    }
    for (int i=1009; i<2000;  i+=13) {
        center.removeAnimal(i);
    }
}

void hiddentest43() {
    AdoptionCenter center;
    centerSetupHidden(center);
    center.setAnimalHealthCondition(123, HealthCondition{"Very bad", 600});
    center.setAnimalHealthCondition(456, HealthCondition{"Very bad", 600});
    center.setAnimalHealthCondition(789, HealthCondition{"Very bad", 600});
    center.display(30, 70, makeFilter("", "Bad", {}), HEALTH);
}

void hiddentest44() {
    AdoptionCenter center;
    centerSetupHidden(center);
    center.display(0, 50, makeFilter("", "", {"Rabies"}));
}

void hiddentest45() {
    AdoptionCenter center;
    centerSetupHidden(center);
    center.incrementAge();
    for (int i=35; i<2000; i+=3)
        center.removeAnimal(i);
    center.incrementAge();
    center.display(30, 80, makeFilter("", "", {}), AGE);
}

void hiddentest46() {
    AdoptionCenter center;
    centerSetupHidden(center);
    center.setAnimalHealthCondition(1995, HealthCondition{"Very bad", 600});
    center.setAnimalSpecialNeeds(1995, "Requires intensive care");
    center.setAnimalHealthCondition(1995, HealthCondition{"Healthy", 0});
    center.setAnimalSpecialNeeds(1995, "Recently cured");
    center.setAnimalHealthCondition(838, HealthCondition{"Fair", 400});
    center.setAnimalSpecialNeeds(838, "Recently improved");
    extern unsigned int animalID;
    center.addAnimal(new Animal{
        animalID++,
        Species{
            "Aardvark",
            "N/A",
        },
        12,
        HealthCondition{
            "Mild fever",
            50,
        },
    });
    center.display(0, 60, makeFilter("", "", {}), NAME);
}

void hiddentest47() {
    AdoptionCenter center;
    centerSetupHidden(center);
    for (int i=22; i<2000; i+=26) {
        extern unsigned int pa3_rand();
        switch (pa3_rand() % 4) {
            case 0:
                center.removeAnimal(i);
                break;
            case 1:
                center.setAnimalHealthCondition(i, HealthCondition{"Custom text", 500});
                break;
            case 2:
                center.addAnimalVaccine(i, "Custom vaccine");
                break;
            case 3:
                center.setAnimalSpecialNeeds(i, "Custom text");
                break;
        }
    }
    center.display(0, 50, makeFilter("Dog", "", {}), NAME);
}

void hiddentest48() {
    AdoptionCenter center;
    centerSetupHidden(center);
    for (int i=14; i<2000; i+=31) {
        extern unsigned int pa3_rand();
        switch (pa3_rand() % 4) {
            case 0:
                center.removeAnimal(i);
                break;
            case 1:
                center.setAnimalHealthCondition(i, HealthCondition{"Custom text", 500});
                break;
            case 2:
                center.addAnimalVaccine(i, "Custom vaccine");
                break;
            case 3:
                if (pa3_rand() % 5 == 0) center.incrementAge();
                center.setAnimalSpecialNeeds(i, "Custom text");
                break;
        }
    }
    center.display(200, 250, makeFilter("", "", {}), AGE);
}

void hiddentest49() {
    AdoptionCenter center;
    centerSetupHidden(center);
    for (int i=27; i<2000; i+=18) {
        extern unsigned int pa3_rand();
        switch (pa3_rand() % 4) {
            case 0:
                center.removeAnimal(i);
                break;
            case 1:
                center.setAnimalHealthCondition(i, HealthCondition{"Custom text", 506});
                break;
            case 2:
                center.addAnimalVaccine(i, "Custom vaccine");
                break;
            case 3:
                center.setAnimalSpecialNeeds(i, "Custom text");
                break;
        }
    }
    for (int i=0; i<6; ++i) {
        string testVaccine = "Test Vaccine " + to_string(i);
        center.addAnimalVaccine(9, testVaccine);
    }
    center.display(1600, 1700, makeFilter("", "", {}), HEALTH);
}

void hiddentest50() {
    AdoptionCenter center;
    centerSetupHidden(center);
    for (int i=1; i<2000; i+=6) {
        extern unsigned int pa3_rand();
        switch (pa3_rand() % 4) {
            case 0:
                center.removeAnimal(i);
                break;
            case 1:
                center.setAnimalHealthCondition(i, HealthCondition{"Custom text", 500});
                break;
            case 2:
                center.addAnimalVaccine(i, "Custom vaccine");
                break;
            case 3:
                center.setAnimalSpecialNeeds(i, "Custom text");
                break;
        }
    }
    center.display(800, 900, makeFilter("", "", {}), VACCINE);
    center.displayPetVaccines(25);
    center.addAnimalVaccine(25, "Custom vaccine");
}

/***********************************************************************/

int main() {
    int test;
    cin >> test;
    cout << boolalpha;
    switch (test) {
        #define TEST(X) case X: test ## X(); break
        #define HIDDEN(X) case (X + 50): hiddentest ## X(); break

        TEST(1); TEST(2); TEST(3); TEST(4); TEST(5); TEST(6); TEST(7); TEST(8);
        HIDDEN(1); HIDDEN(2); HIDDEN(3); HIDDEN(4); HIDDEN(5); HIDDEN(6); HIDDEN(7); HIDDEN(8);

        TEST(9); TEST(10); TEST(11); TEST(12); TEST(13); TEST(14);
        HIDDEN(9); HIDDEN(10); HIDDEN(11); HIDDEN(12); HIDDEN(13); HIDDEN(14);

        TEST(15); TEST(16); TEST(17); TEST(18); TEST(19); TEST(20);
        HIDDEN(15); HIDDEN(16); HIDDEN(17); HIDDEN(18); HIDDEN(19); HIDDEN(20);

        TEST(21); TEST(22); TEST(23); TEST(24); TEST(25); TEST(26); TEST(27); TEST(28); TEST(29); TEST(30);
        HIDDEN(21); HIDDEN(22); HIDDEN(23); HIDDEN(24); HIDDEN(25); HIDDEN(26); HIDDEN(27); HIDDEN(28); HIDDEN(29); HIDDEN(30);

        TEST(31); TEST(32);
        HIDDEN(31); HIDDEN(32);

        TEST(33); TEST(34); TEST(35); TEST(36); TEST(37); TEST(38);
        HIDDEN(33); HIDDEN(34); HIDDEN(35); HIDDEN(36); HIDDEN(37); HIDDEN(38);

        TEST(39); TEST(40); TEST(41); TEST(42);
        HIDDEN(39); HIDDEN(40); HIDDEN(41); HIDDEN(42);

        TEST(43); TEST(44); TEST(45); TEST(46); TEST(47); TEST(48); TEST(49); TEST(50);
        HIDDEN(43); HIDDEN(44); HIDDEN(45); HIDDEN(46); HIDDEN(47); HIDDEN(48); HIDDEN(49); HIDDEN(50);

        default:
            cout << "Unrecognized test case" << endl;
    }
}