#ifndef __ADOPTIONCENTER_H__
#define __ADOPTIONCENTER_H__

#include "animal.h"
#include "bst.h"

enum SortCriteria {
    NAME,
    AGE,
    HEALTH,
    VACCINE,
    ID // equals to number of criterias
};

class AdoptionCenter {
    private:
        Animal** animals;
        unsigned int numAnimals;

        BST sortedAnimals[ID];

    public:
        AdoptionCenter();
        AdoptionCenter(const AdoptionCenter&) = delete;
        AdoptionCenter& operator=(const AdoptionCenter&) = delete;
        ~AdoptionCenter();

        void addAnimal(Animal* a);
        bool removeAnimal(unsigned int id);

        void incrementAge();
        void setAnimalHealthCondition(unsigned int id, const HealthCondition& h);
        void addAnimalVaccine(unsigned int id, const std::string& v);
        void setAnimalSpecialNeeds(unsigned int id, const std::string& n);
        
        void display(unsigned int start, unsigned int stop, const Filter& filter, SortCriteria criteria = ID) const;
        void displayPetVaccines(unsigned int id) const;
};

#endif // __ADOPTIONCENTER_H__