#include "adoptionCenter.h"
#include <iostream>
using namespace std;


AdoptionCenter::AdoptionCenter(): animals(nullptr), numAnimals(0), sortedAnimals{
    BST([](const Animal* a1, const Animal* a2) -> int {
        return a1->getSpecies().compare(a2->getSpecies());
    }),
    BST([](const Animal* a1, const Animal* a2) -> int {
        return a1->getAge() - a2->getAge();
    }),
    BST([](const Animal* a1, const Animal* a2) -> int {
        return static_cast<int>(a1->getHealthCondition().severity) - static_cast<int>(a2->getHealthCondition().severity);
    }),
    BST([](const Animal* a1, const Animal* a2) -> int {
        return static_cast<int>(a1->getVaccinationStatus().getTotalHashValue()) - static_cast<int>(a2->getVaccinationStatus().getTotalHashValue());
    }),
} {}

AdoptionCenter::~AdoptionCenter() {
    for (unsigned int i=0; i<numAnimals; ++i)
        delete animals[i];
    delete [] animals;
}

void AdoptionCenter::addAnimal(Animal* a) {
    Animal** temp = new Animal*[numAnimals + 1];
    for (unsigned int i=0; i<numAnimals; ++i)
        temp[i] = animals[i];
    temp[numAnimals++] = a;
    delete [] animals;
    animals = temp;

    for (SortCriteria c = NAME; c < ID; c = static_cast<SortCriteria>(c+1)) {
        sortedAnimals[c].insert(a);
    }
}

bool AdoptionCenter::removeAnimal(unsigned int id) {
    // Base case 0
    if (numAnimals == 0) {
        return false;
    }
    // Base case 1
    if (numAnimals == 1) {
        if (animals[0]->getID() == id) {
            delete animals[0];
            delete [] animals;
            animals = nullptr;
            return true;
        }
        else return false;
    }

    Animal** temp = new Animal*[numAnimals - 1];
    bool found = false;
    for (unsigned int i=0; i<numAnimals; ++i) {
        if (animals[i]->getID() == id) {
            found = true;

            for (SortCriteria c = NAME; c < ID; c = static_cast<SortCriteria>(c+1)) {
                sortedAnimals[c].remove(animals[i]);
            }

            delete animals[i];
        }
        else {
            if (i == numAnimals-1 && !found) break;
            temp[i - found] = animals[i];
        }
    }
    if (!found) {
        delete [] temp;
    }
    else {
        delete [] animals;
        animals = temp;
        --numAnimals;
    }
    return found;
}

void AdoptionCenter::incrementAge()
{
    for (unsigned int i=0; i<numAnimals; ++i)
        animals[i]->incrementAge();
}

void AdoptionCenter::setAnimalHealthCondition(unsigned int id, const HealthCondition& h)
{
    for (unsigned int i=0; i<numAnimals; ++i) {
        if (animals[i]->getID() == id) {
            sortedAnimals[HEALTH].remove(animals[i]);
            animals[i]->setHealthCondition(h);
            sortedAnimals[HEALTH].insert(animals[i]);
        }
    }
}

void AdoptionCenter::addAnimalVaccine(unsigned int id, const string& v)
{
    for (unsigned int i=0; i<numAnimals; ++i) {
        if (animals[i]->getID() == id) {
            sortedAnimals[VACCINE].remove(animals[i]);
            animals[i]->addVaccine(v);
            sortedAnimals[VACCINE].insert(animals[i]);
        }
    }
}

void AdoptionCenter::setAnimalSpecialNeeds(unsigned int id, const std::string& n)
{
    for (unsigned int i=0; i<numAnimals; ++i) {
        if (animals[i]->getID() == id) {
            animals[i]->setSpecialNeeds(n);
        }
    }
}

void AdoptionCenter::display(unsigned int start, unsigned int stop, const Filter& filter, SortCriteria criteria) const {
    unsigned int displayCount = stop - start;
    if (criteria == ID) {
        for (unsigned int i=0; i<numAnimals; ++i) {
            if (filter.match(*animals[i])) {
                animals[i]->display(start, displayCount);
            }
        }
    }
    else {
        sortedAnimals[criteria].print(start, displayCount, filter);
    }
}

void AdoptionCenter::displayPetVaccines(unsigned int id) const
{
    unsigned int i = 0;
    for (; i<numAnimals; ++i) {
        if (animals[i]->getID() == id) {
            VaccinationStatus v = animals[i]->getVaccinationStatus();
            if (v.numVaccines == 0)
                cout << "No vaccines found." << endl;
            else
                for (unsigned int j = 0; j < VACCINE_TABLE_SIZE; ++j) {
                    if (v.vaccineHashTable[j].length() > 0)
                        cout << v.vaccineHashTable[j] << endl;
                }
            return;
        }
    }
    if (i == numAnimals)
        cout << "ID not found in database." << endl;
}
