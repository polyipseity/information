#ifndef __BST_H__
#define __BST_H__

#include <iostream>
#include "animal.h"

struct Filter {
    std::string speciesFilter {""};
    std::string healthFilter {""};
    std::string vaccineFilter[VACCINE_TABLE_SIZE] {};

    bool match(const Animal& a) const;
};

struct AnimalLLnode;
struct BSTnode;
typedef int (*AnimalComparator)(const Animal*, const Animal*);

class BST {
    friend void printTest(const BST&, unsigned int);

    private:
        BSTnode* root;
        const AnimalComparator comparator;

        BSTnode*& findMinNode();
    
    public:
        BST(const AnimalComparator comparator): root(nullptr), comparator(comparator) {}
        ~BST();

        bool isEmpty() const { return root == nullptr; }

        void insert(const Animal*);
        void remove(const Animal*);

        void print(unsigned int& ignoreCount, unsigned int& displayCount, const Filter& filter) const;
};

struct AnimalLLnode {
    const Animal* animal;
    AnimalLLnode* next;

    AnimalLLnode(const Animal* a, AnimalLLnode* next = nullptr): animal(a), next(next) {}
    ~AnimalLLnode() = default;

    void print(unsigned int& ignoreCount, unsigned int& displayCount, const Filter& filter) const;
};

struct BSTnode {
    AnimalLLnode* head;
    BST left;
    BST right;
    
    BSTnode(const Animal* a, const AnimalComparator c) : head(new AnimalLLnode(a, nullptr)), left(c), right(c) { }
    BSTnode(const BSTnode&) = delete;
    BSTnode& operator=(const BSTnode&) = delete;
    ~BSTnode();

    void addAnimal(const Animal* a);
    void removeAnimal(const Animal* a);
};

#endif // __BST_H__