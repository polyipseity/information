#ifndef __ANIMAL_H__
#define __ANIMAL_H__

#include <iostream>
#include "datatypes.h"

class Animal {
    private:
        unsigned int id;
        Species species;
        unsigned int age;

        HealthCondition healthCondition;
        VaccinationStatus vaccineStatus;
        
        std::string specialNeeds;
    
    public:
        Animal(
            unsigned int id, const Species& s, unsigned int a, 
            const HealthCondition& h = NORMAL_HEALTH,
            const VaccinationStatus& v = VaccinationStatus(),
            const std::string& n = ""
        ): id(id), species(s), age(a), healthCondition(h), vaccineStatus(v), specialNeeds(n) {}
        Animal(const Animal&) = delete;
        Animal& operator=(const Animal&) = delete;

        unsigned int getID() const { return id; }
        std::string getSpecies() const { return species.name + " (" + species.breed + ")"; }
        unsigned int getAge() const { return age; }
        const HealthCondition& getHealthCondition() const { return healthCondition; }
        const VaccinationStatus& getVaccinationStatus() const { return vaccineStatus; }
        std::string getSpecialNeeds() const { return specialNeeds; }

        void incrementAge() { ++age; }
        void setHealthCondition(const HealthCondition& h) { healthCondition = h; }
        void setSpecialNeeds(const std::string& n) { specialNeeds = n; }
        void addVaccine(const std::string& v) { vaccineStatus.addVaccine(v); }

        void display(unsigned int& ignoreCount, unsigned int& displayCount) const;
};


#endif // __ANIMAL_H__