#include "datatypes.h"
#include <iostream>
using namespace std;

unsigned int sumStringChars(const string& str) 
{
    unsigned int sum = 0;
    for (unsigned int i=0; i<str.length(); ++i)
        sum += static_cast<unsigned int>(str[i]);
    return sum;
}

VaccinationStatus::VaccinationStatus(): numVaccines(0) {}

void VaccinationStatus::addVaccine(const string& v)
{
    if (numVaccines > VACCINE_TABLE_SIZE / 2) {
        cout << "This system does not support having taken more than " << numVaccines << " vaccines." << endl;
        return;
    }

    unsigned int k = sumStringChars(v);
    unsigned int h = k % VACCINE_TABLE_SIZE;
    unsigned int i = 0;
    while (vaccineHashTable[h].length() > 0) {
        if (vaccineHashTable[h] == v) {
            cout << "This animal has already taken " << v << "." << endl;
            return;
        }
        ++i;
        h = (k + i * i) % VACCINE_TABLE_SIZE;
    }
    vaccineHashTable[h] = v;
    ++numVaccines;
}

bool VaccinationStatus::hasVaccine(const string& v) const
{
    unsigned int k = sumStringChars(v);
    unsigned int h = k % VACCINE_TABLE_SIZE;
    unsigned int i = 0;
    while (vaccineHashTable[h].length() > 0) {
        if (vaccineHashTable[h] == v) {
            return true;
        }
        ++i;
        h = (k + i * i) % VACCINE_TABLE_SIZE;
    }
    return false;
}

unsigned int VaccinationStatus::getTotalHashValue() const 
{
    unsigned int hash = 0;
    for (unsigned int i=0; i<VACCINE_TABLE_SIZE; ++i)
        hash += sumStringChars(vaccineHashTable[i]);
    return hash * numVaccines;
}
