#ifndef __RANDOMANIMALGENERATOR_H__
#define __RANDOMANIMALGENERATOR_H__

class Animal;
extern unsigned int animalID;

Animal* createRandomAnimal();

#endif //__RANDOMANIMALGENERATOR_H__