#include "bst.h"
using namespace std;

bool containAnyWords(string src, string filterWords) {
    auto strToLower = [](string& str) {
        for (char& c: str) c = tolower(c);
    };
    strToLower(src);
    strToLower(filterWords);
    size_t found = filterWords.find(' ');
    while (found != string::npos) {
        if (src.find(filterWords.substr(0, found)) != string::npos)
            return true;
        filterWords = filterWords.substr(found+1);
        found = filterWords.find(' ');
    }
    return src.find(filterWords) != string::npos;
}

bool Filter::match(const Animal& a) const
{
    bool speciesMatch = speciesFilter.length() > 0 ? containAnyWords(a.getSpecies(), speciesFilter) : true;
    bool healthMatch = healthFilter.length() > 0 ? containAnyWords(a.getHealthCondition().description, healthFilter) : true;
    bool vaccineMatch = true;
    for (unsigned int i=0; i<VACCINE_TABLE_SIZE; ++i)
        if (vaccineFilter[i].length() > 0)
            vaccineMatch &= a.getVaccinationStatus().hasVaccine(vaccineFilter[i]);
    
    return speciesMatch && healthMatch && vaccineMatch;
}


void AnimalLLnode::print(unsigned int& ignoreCount, unsigned int& displayCount, const Filter& filter) const
{
    if (next) {
        next->print(ignoreCount, displayCount, filter);
    }
    if (filter.match(*animal)) {
        animal->display(ignoreCount, displayCount);
    }
}

BSTnode::~BSTnode()  {
    while (head) {
        AnimalLLnode* next = head->next;
        delete head;
        head = next;
    }
}

void BSTnode::addAnimal(const Animal* a) {
    if (a->getID() > head->animal->getID())
        head = new AnimalLLnode(a, head);
    else {
        AnimalLLnode* cur = head;
        while (cur->next && a->getID() < cur->next->animal->getID()) {
            cur = cur->next;
        }
        cur->next = new AnimalLLnode(a, cur->next);
    }
}

void BSTnode::removeAnimal(const Animal* a) {
    if (head) {
        if (head->animal == a) {
            AnimalLLnode* next = head->next;
            delete head;
            head = next;
        }
        else {
            AnimalLLnode* prev = head;
            AnimalLLnode* cur = head->next;
            while (cur && cur->animal != a) {
                prev = prev->next;
                cur = cur->next;
            }
            if (cur) {
                prev->next = cur->next;
                delete cur;
            }
        }
    }
}

BST::~BST() {
    delete root;
}

BSTnode*& BST::findMinNode()
{
    return root->left.isEmpty() ? root : root->left.findMinNode();
}

void BST::insert(const Animal* a)
{
    if (isEmpty())
        root = new BSTnode(a, comparator);

    else if (comparator(a, root->head->animal) < 0)
        root->left.insert(a);  // Recursion on the left sub-tree

    else if (comparator(a, root->head->animal) > 0)
        root->right.insert(a); // Recursion on the right sub-tree
    
    else
        root->addAnimal(a);
}

void BST::remove(const Animal* a)
{
    if (isEmpty())             // Item is not found; do nothing
        return;
    
    if (comparator(a, root->head->animal) < 0)        // Remove from the left subtree
        root->left.remove(a);
    else if (comparator(a, root->head->animal) > 0)   // Remove from the right subtree
        root->right.remove(a);
    else {
        root->removeAnimal(a);
        if (root->head) return; // Linked list still contains item

        if (root->left.root && root->right.root) // Found node has 2 children
        {
            BSTnode* rightMin = root->right.findMinNode();
            root->head = rightMin->head;
            rightMin->head = nullptr;
            root->right.findMinNode() = rightMin->right.root;
            rightMin->right.root = nullptr;
            delete rightMin;
        }
        else                        // Found node has 0 or 1 child
        {
            BSTnode* deleting_node = root; // Save the root to delete first
            root = (root->left.isEmpty()) ? root->right.root : root->left.root;

            // Set subtrees to nullptr before removal due to recursive destructor
            deleting_node->left.root = deleting_node->right.root = nullptr;
            delete deleting_node;
        }
    }
}

void BST::print(unsigned int& ignoreCount, unsigned int& displayCount, const Filter& filter) const
{
    if (isEmpty())                 // Base case
       return;

    root->left.print(ignoreCount, displayCount, filter);  // Recursion: left sub-tree
    root->head->print(ignoreCount, displayCount, filter); // Print the node value
    root->right.print(ignoreCount, displayCount, filter); // Recursion: right sub-tree
}