#ifndef __DATATYPES_H__
#define __DATATYPES_H__

#include <string>

struct Species {
    std::string name;
    std::string breed;
};

struct HealthCondition {
    std::string description;
    unsigned int severity;
};

const HealthCondition NORMAL_HEALTH {"Healthy", 0};

const unsigned int VACCINE_TABLE_SIZE = 23;

struct VaccinationStatus {
    std::string vaccineHashTable[VACCINE_TABLE_SIZE];
    unsigned int numVaccines;

    VaccinationStatus();

    void addVaccine(const std::string& v);
    bool hasVaccine(const std::string& v) const;

    unsigned int getTotalHashValue() const;
};

#endif //__DATATYPES_H__