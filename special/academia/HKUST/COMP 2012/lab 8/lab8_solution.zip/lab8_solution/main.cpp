#include <iostream>
#include <algorithm>
#include "ShoppingCart.h"

int main() {

    int test;
    std::cin >> test;
    ShoppingCart cart1;
    ShoppingCart cart2;
    ShoppingCart cart3;
    ShoppingCart cart4;
    ShoppingCart cart5;
    ShoppingCart cart6;
    ShoppingCart cart7;
    ShoppingCart cart8;
    ShoppingCart cart9;
    ShoppingCart cart10;

    std::vector<Product> expensiveProducts4;
    std::vector<Product> expensiveProducts5;
    std::vector<Product> Products6;
    std::vector<Product> expensiveProducts9;
    std::vector<Product> products10;

    switch (test) {
        case 1:
            std::cout << "\n================================Case1================================\n";
            cart1.addProduct(Product("Shirt", 29.99));
            cart1.addProduct(Product("Jeans", 49.99));
            cart1.addProduct(Product("Shoes", 79.99));
            cart1.addProduct(Product("Watch", 99.99));
            cart1.addProduct(Product("Hat", 19.99));

            cart1.displayProducts();
            std::cout << "Total price: $" << cart1.getTotalPrice() << "\n";

            cart1.removeProduct("Shoes");
            cart1.displayProducts();
            std::cout << "Total price: $" << cart1.getTotalPrice() << "\n";
        break;
        case 2:
            std::cout << "\n================================Case2================================\n";

            cart2.addProduct(Product("Shirt", 29.99));
            cart2.addProduct(Product("Jeans", 49.99));
            cart2.addProduct(Product("Shoes", 79.99));
            cart2.addProduct(Product("Watch", 99.99));
            cart2.addProduct(Product("Hat", 19.99));

            cart2.sortByPrice();
            cart2.displayProducts();
            std::cout << "Total price: $" << cart2.getTotalPrice() << "\n";
        break;
        case 3:
            std::cout << "\n================================Case3================================\n";

            cart3.addProduct(Product("Shirt", 29.99));
            cart3.addProduct(Product("Jeans", 49.99));
            cart3.addProduct(Product("Shoes", 79.99));
            cart3.addProduct(Product("Watch", 99.99));
            cart3.addProduct(Product("Hat", 19.99));

            cart3.sortByName();
            cart3.displayProducts();
            std::cout << "Total price: $" << cart3.getTotalPrice() << "\n";

            cart3.removeProduct("Jeans");
            cart3.displayProducts();
            std::cout << "Total price: $" << cart3.getTotalPrice() << "\n";
        break;
        case 4:
            std::cout << "\n================================Case4================================\n";

            cart4.addProduct(Product("Shirt", 29.99));
            cart4.addProduct(Product("Jeans", 49.99));
            cart4.addProduct(Product("Shoes", 79.99));
            cart4.addProduct(Product("Watch", 99.99));
            cart4.addProduct(Product("Hat", 19.99));

            expensiveProducts4 = cart4.getExpensiveProducts(50);
            std::cout << "Expensive products in the shopping cart:\n";
            for (const Product& product : expensiveProducts4) {
                product.print();
                }
        break;
        case 5:
            std::cout << "\n================================Case5================================\n";

            cart5.addProduct(Product("Shirt", 29.99));
            cart5.addProduct(Product("Jeans", 49.99));
            cart5.addProduct(Product("Shoes", 79.99));
            cart5.addProduct(Product("Watch", 99.99));
            cart5.addProduct(Product("Hat", 19.99));
            cart5.displayProducts();
            std::cout << "Total price: $" << cart5.getTotalPrice() << "\n";

            cart5.applyDiscount(0.9);
            cart5.displayProducts();
            std::cout << "Total price: $" << cart5.getTotalPrice() << "\n";
            
            expensiveProducts5 = cart5.getExpensiveProducts(50);
            std::cout << "Expensive products in the shopping cart:\n";
            for (const Product& product : expensiveProducts5) {
                product.print();
                }
        break;
        case 6:
            std::cout << "\n================================Case6================================\n";

            cart6.addProduct(Product("Shirt", 29.99));
            cart6.addProduct(Product("Jeans", 49.99));
            cart6.addProduct(Product("Shoes", 79.99));
            cart6.addProduct(Product("Watch", 99.99));
            cart6.addProduct(Product("Hat", 19.99));
            cart6.displayProducts();
            std::cout << "Total price: $" << cart6.getTotalPrice() << "\n";
            Products6 = cart6.getProductsInPriceRange(50, 100);
            std::cout << "Products within a given price range in the shopping cart:\n";
            for (const Product& product : Products6) {
                product.print();
            }
        break;
        case 7:
            std::cout << "\n================================Case7================================\n";

            cart7.addProduct(Product("Shirt", 29.99));
            cart7.addProduct(Product("Jeans", 49.99));
            cart7.addProduct(Product("Shoes", 79.99));
            cart7.addProduct(Product("Watch", 99.99));
            cart7.addProduct(Product("Hat", 19.99));

            cart7.displayProducts();
            std::cout << "Total price: $" << cart7.getTotalPrice() << "\n";

            cart7.removeProduct("Shirt");
            cart7.removeProduct("Watch");
            cart7.displayProducts();
            std::cout << "Total price: $" << cart7.getTotalPrice() << "\n";
            break;
        case 8:
            std::cout << "\n================================Case8================================\n";

            cart8.addProduct(Product("Shirt", 29.99));
            cart8.addProduct(Product("Jeans", 49.99));
            cart8.addProduct(Product("Shoes", 79.99));
            cart8.addProduct(Product("Watch", 99.99));
            cart8.addProduct(Product("Hat", 19.99));

            std::cout << "Sort by Name:\n";
            cart8.sortByName();
            cart8.displayProducts();

            std::cout << "Sort by Price:\n";
            cart8.sortByPrice();
            cart8.displayProducts();
            break;
        case 9:
            std::cout << "\n================================Case9================================\n";

            cart9.addProduct(Product("T-shirt", 19.99));
            cart9.addProduct(Product("Shorts", 39.99));
            cart9.addProduct(Product("Sneakers", 89.99));
            cart9.addProduct(Product("Watch", 129.99));
            cart9.addProduct(Product("Cap", 14.99));

            cart9.displayProducts();
            std::cout << "Total price: $" << cart9.getTotalPrice() << "\n";

            cart9.applyDiscount(0.85);
            cart9.displayProducts();
            std::cout << "Total price: $" << cart9.getTotalPrice() << "\n";

            expensiveProducts9 = cart9.getExpensiveProducts(50);
            std::cout << "Expensive products in the shopping cart:\n";
            for (const Product& product : expensiveProducts9) {
                product.print();
            }
            break;
        case 10:
            std::cout << "\n================================Case10================================\n";

            cart10.addProduct(Product("Dress", 59.99));
            cart10.addProduct(Product("Pants", 49.99));
            cart10.addProduct(Product("Sandals", 39.99));
            cart10.addProduct(Product("Necklace", 69.99));
            cart10.addProduct(Product("Sunglasses", 29.99));

            cart10.displayProducts();
            std::cout << "Total price: $" << cart10.getTotalPrice() << "\n";

            products10 = cart10.getProductsInPriceRange(40, 70);
            std::cout << "Products within a given price range in the shopping cart:\n";
            for (const Product& product : products10) {
                product.print();
            }
            break;
        default:
            std::cout << "Unrecognized test case." << std::endl;
            break;
    }
    return 0;
}