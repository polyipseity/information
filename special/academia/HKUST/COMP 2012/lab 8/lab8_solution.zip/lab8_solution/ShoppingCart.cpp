#include "ShoppingCart.h"
#include <numeric>

// TODO1: Implement the addProduct method in the ShoppingCart class.
// Objective: Understand how to use std::vector to store and manage a collection of objects.
// Hints: You can directly use STL algorithm for implement.
void ShoppingCart::addProduct(const Product& product) {
    products.push_back(product);
}

// TODO2: Implement the getTotalPrice method in the ShoppingCart class.
// Objective: Understand how to use STL algorithms to operate elements from a vector.
double ShoppingCart::getTotalPrice() const {
    return std::accumulate(products.begin(), products.end(), 0.0, 
        [](double sum, const Product& p) { return sum + p.price; });
}

// TODO3: Implement the removeProduct method in the ShoppingCart class, which removes the product from cart.
// Objective: Understand how to use STL algorithms to search and remove an element from a vector.
// Hints: You can use find_if() & erase() or erase() & remove_if() for implement.
void ShoppingCart::removeProduct(const std::string& productName) {
    std::vector<Product>::iterator it = std::find_if(products.begin(), products.end(),
    [&productName](const Product& p) { return p.name == productName; });
    if (it != products.end()) {
        products.erase(it);
    }
}
// void ShoppingCart::removeProduct(const std::string& productName) {
//     products.erase(std::remove_if(products.begin(), products.end(),
//         [&productName](const Product& p) { return p.name == productName; }),
//         products.end());
// }

// TODO4.1: Implement the sortByPrice method in the ShoppingCart class.
// Objective: Understand how to use STL algorithms to sort a vector of objects based on a specific criteria.
// You can Use the std::sort algorithm to sort the products vector and define a lambda function or a functor to specify the sorting criteria based on the price member of the Product class.
void ShoppingCart::sortByPrice() {
    std::sort(products.begin(), products.end(), [](const Product& p1, const Product& p2) {
        return p1.price < p2.price;
    });
}

// TODO4.2: Implement the sortByName method in the ShoppingCart class.
// Objective: Understand how to use STL algorithms to sort a vector of objects based on a specific criteria.
void ShoppingCart::sortByName() {
    std::sort(products.begin(), products.end(), [](const Product& p1, const Product& p2) {
        return p1.name < p2.name;
    });
}

// TODO5: Implement the applyDiscount method in the ShoppingCart class.
// Hints: You can use std::transform.
void ShoppingCart::applyDiscount(double discountRate) {
    std::transform(products.begin(), products.end(), products.begin(), [&](Product& product) {
        product.price *= discountRate;
        return product;
    });
}

// TODO6: Implement the getProductsInPriceRange method in the ShoppingCart class.
std::vector<Product> ShoppingCart::getProductsInPriceRange(double minPrice, double maxPrice) {
    std::vector<Product> productsInRange;

    for (std::vector<Product>::iterator it = products.begin(); it != products.end(); ++it) {
        if (it->price >= minPrice && it->price <= maxPrice) {
            productsInRange.push_back(*it);
        }
    }
    
    return productsInRange;
}

// GIVEN: Implement the getExpensiveProducts method in the ShoppingCart class.
// You should filter out expensive products (>threshold) and sort them by price;
// Hints: You can use std::copy_if algorithm and std::sort algorithm, you also need compareByPrice() and isExpensive().
std::vector<Product> ShoppingCart::getExpensiveProducts(double threshold) const {
    std::vector<Product> expensiveProducts;

    std::copy_if(products.begin(), products.end(), std::back_inserter(expensiveProducts),
                [&threshold](const Product& p) { return Product::isExpensive(p, threshold); });

    std::sort(expensiveProducts.begin(), expensiveProducts.end(), Product::compareByPrice);
    return expensiveProducts;
}