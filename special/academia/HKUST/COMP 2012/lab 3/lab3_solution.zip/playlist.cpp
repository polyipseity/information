#include "playlist.h"
#include <iostream>

PlayList::PlayList(const string& username, int capacity): username(username), capacity(capacity){
    songs = new const Song*[capacity];  // assuming a maximum of 100 songs
    for (int i = 0; i < capacity; i++) {
        songs[i] = nullptr;
    }
}

PlayList::PlayList(const string& username, const PlayList& playlist, int capacity): username(username), capacity(capacity) {
    songs = new const Song*[capacity];  // assuming a maximum of 100 songs
    for (int i = 0; i < capacity; i++) {
        if ((i < playlist.capacity) && (playlist.songs[i] != nullptr)) {
            songs[i] = playlist.songs[i];
        } else {
            songs[i] = nullptr;
        }
    }
}

PlayList::~PlayList() {
    delete[] songs;
}

void PlayList::addSong(const Song* song) {
    for (int i = 0; i < capacity; i++) {
        if (songs[i] == nullptr) {
            songs[i] = song;
            break;
        }
    }
}

void PlayList::removeSong(const string& name) {
    for (int i = 0; i < capacity; i++) {
        if (songs[i] != nullptr && songs[i]->getName() == name) {
            songs[i] = nullptr;
            // Shift the remaining pointers forward
            for (int j = i; j < capacity-1; j++) {
                songs[j] = songs[j + 1];
            }
            songs[capacity] = nullptr;  // Set the last pointer to nullptr
            break;
        }
    }
}

string PlayList::getUsername() const {
    return username;
}

void PlayList::display() const {
    cout << "========================================" << endl; 
    cout << "Playlist of " << username << endl;
    for (int i = 0; i < capacity; i++) {
        if (songs[i] != nullptr) {
            cout << i << ". " << songs[i]->getName() << " - " << songs[i]->getSinger()->getName() << endl;
        }
    }
    cout << "========================================" << endl;
}
