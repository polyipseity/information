#ifndef __USERPIECE_H__
#define __USERPIECE_H__

#include "piece.h"

using Knight = OmniLeaper<'N', 2, 1>;

using Rook = OmniRider<'R', 1, 0>;

using Bishop = OmniRider<'B', 1, 1>;

using Queen = Compound<'Q', Rook, Bishop>;

using King = Compound<'K', OmniLeaper<'K', 1, 0>, OmniLeaper<'K', 1, 1>>;

using BasicPawn = Divergent<'P', Leaper<'P', 0, 1>, Compound<'P', Leaper<'P', 1, 1>, Leaper<'P', -1, 1>>>;

class Pawn: public BasicPawn {
    public:
        Pawn(Color color): BasicPawn(color) {}
        virtual Piece* clone() const { return new Pawn{*this}; }

        virtual BooleanMap getMoves(const Board& board) const override;
};

bool isRoyal(const Piece* piece);

#endif // __USERPIECE_H__