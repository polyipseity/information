#include <iostream>
#include "board.h"
#include "piece.h"
using namespace std;

Board::Board(const Board& board) : pieces{nullptr}, isWhiteTurn(board.isWhiteTurn)
{
    for (_RANK r = _8; r >= _1; r = static_cast<_RANK>(r-1)) {
        for (_FILE f = _A; f <= _H; f = static_cast<_FILE>(f+1)) {
            if (board.piece(f, r)) {
                piece(f, r) = board.piece(f, r)->clone();
                piece(f, r)->setPosition(Position{f, r});
            }
        }
    }
    if (board.selectedPiece) {
        selectedPiece = piece(board.selectedPiece->getPosition());
        moveMap = board.moveMap;
    }
    if (board.royalPieces[BLACK])
        royalPieces[BLACK] = piece(board.royalPieces[BLACK]->getPosition());
    if (board.royalPieces[WHITE])
        royalPieces[WHITE] = piece(board.royalPieces[WHITE]->getPosition());
}

Board::~Board() {
    for (_RANK r = _8; r >= _1; r = static_cast<_RANK>(r-1)) {
        for (_FILE f = _A; f <= _H; f = static_cast<_FILE>(f+1)) {
            delete piece(f, r);
        }
    }
}

void Board::move(const Position& destPos)
{
    // Safeguard against misusage of move()
    if (!selectedPiece) {
        cout << "ERROR: Piece not selected, cannot call move()" << endl;
        return;
    }

    if (piece(destPos)) {
        delete piece(destPos);
    }

    piece(destPos) = selectedPiece;
    piece(selectedPiece->getPosition()) = nullptr;
    selectedPiece->setPosition(destPos);

    isWhiteTurn = !isWhiteTurn;
}

void Board::validateMoveMap()
{
    for (_RANK r = _8; r >= _1; r = static_cast<_RANK>(r-1)) {
        for (_FILE f = _A; f <= _H; f = static_cast<_FILE>(f+1)) {
            if (!moveMap.cell(f, r))
                continue;
            
            Board tryMoveBoard {*this};
            tryMoveBoard.move(Position{f, r});

            BooleanMap opponentCaptureMap = tryMoveBoard.getAttackingMap();
            Piece* royalPiece = tryMoveBoard.royalPieces[isWhiteTurn ? WHITE : BLACK];
            if (royalPiece && opponentCaptureMap.cell(royalPiece->getPosition())) {
                moveMap.cell(f, r) = false;
            }
        }
    }
}

BooleanMap Board::getAttackingMap() const
{
    BooleanMap map {};
    BooleanMap opponentMap = getOpponentMap(isWhiteTurn ? WHITE : BLACK);

    for (_RANK r = _8; r >= _1; r = static_cast<_RANK>(r-1)) {
        for (_FILE f = _A; f <= _H; f = static_cast<_FILE>(f+1)) {
            if (!piece(f, r))
                continue;
            
            if (piece(f, r)->isWhite() ^ isWhiteTurn)
                continue;
            
            BooleanMap captureMap = piece(f, r)->getMoves(*this);
            captureMap &= opponentMap;
            map |= captureMap;
        }
    }

    return map;
}

