template <char N, int F, int R>
class Leaper: public NamedPiece<N> {
    public:
        Leaper(Color color): NamedPiece<N>(color) {}
        virtual Piece* clone() const override { return new Leaper{*this}; }

        virtual BooleanMap getMoves(const Board& board) const override;
};

template <char N, int F, int R, int RANGE>
class Rider: public NamedPiece<N> {
    public:
        Rider(Color color): NamedPiece<N>(color) {}
        virtual Piece* clone() const override { return new Rider{*this}; }

        virtual BooleanMap getMoves(const Board& board) const override;
};

template <char N, typename P1, typename P2>
class Compound: public NamedPiece<N> {
    public:
        Compound(Color color): NamedPiece<N>(color) {}
        virtual Piece* clone() const override { return new Compound{*this}; }

        virtual BooleanMap getMoves(const Board& board) const override;
};

template <char N, typename M, typename C>
class Divergent: public NamedPiece<N> {
    public:
        Divergent(Color color): NamedPiece<N>(color) {}
        virtual Piece* clone() const override { return new Divergent{*this}; }

        virtual BooleanMap getMoves(const Board& board) const override;
};

template <char N, int F, int R>
BooleanMap Leaper<N, F, R>::getMoves(const Board& board) const
{
    BooleanMap map {};
    Vector vec = this->isWhite() ? Vector{F, R} : Vector{-F, -R};
    Position newPos = vec + this->position;
    
    if (newPos == this->position)
        return map;
    
    if (board.piece(newPos) && !this->isOpponent(*board.piece(newPos)))
        return map;

    map.cell(newPos) = true;
    return map;
}

template <char N, int F, int R, int RANGE>
BooleanMap Rider<N, F, R, RANGE>::getMoves(const Board& board) const
{
    BooleanMap map {};
    Vector vec = this->isWhite() ? Vector{F, R} : Vector{-F, -R};
    Position newPos = this->position;
    for (int i = 1; i <= RANGE; ++i) {
        newPos = (vec * i) + this->position;

        if (newPos == this->position)
            break;

        if (board.piece(newPos)) {
            if (this->isOpponent(*board.piece(newPos)))
                map.cell(newPos) = true;
            break;
        }
        
        map.cell(newPos) = true;
    }

    return map;
}

template <char N, typename P1, typename P2>
BooleanMap Compound<N, P1, P2>::getMoves(const Board& board) const
{
    BooleanMap map {};

    P1* p1 = new P1(this->color);
    Board temp1 = board.getTempBoard(p1, this->position);
    map |= p1->getMoves(temp1);

    P2* p2 = new P2(this->color);
    Board temp2 = board.getTempBoard(p2, this->position);
    map |= p2->getMoves(temp2);

    return map;
}

template <char N, typename M, typename C>
BooleanMap Divergent<N, M, C>::getMoves(const Board& board) const
{
    BooleanMap map {};

    M* movePiece = new M(this->color);
    Board temp1 = board.getTempBoard(movePiece, this->position);
    BooleanMap moveMap = movePiece->getMoves(temp1);
    moveMap &= ~board.getOpponentMap(this->color);
    map |= moveMap;

    C* capturePiece = new C(this->color);
    Board temp2 = board.getTempBoard(capturePiece, this->position);
    BooleanMap captureMap = capturePiece->getMoves(temp2);
    captureMap &= board.getOpponentMap(this->color);
    map |= captureMap;

    return map;
}