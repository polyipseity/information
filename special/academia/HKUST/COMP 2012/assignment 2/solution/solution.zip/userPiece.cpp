#include "userPiece.h"

bool isRoyal(const Piece* piece)
{
    if (dynamic_cast<const King*>(piece)) return true;
    return false;
}

BooleanMap Pawn::getMoves(const Board &board) const
{
    BooleanMap map = BasicPawn::getMoves(board);

    if (isWhite() && position.rank == _2 && !board.piece(position.file, _3) && !board.piece(position.file, _4)) {
        map.cell(position.file, _4) = true;
    }
    else if (!isWhite() && position.rank == _7 && !board.piece(position.file, _6) && !board.piece(position.file, _5)) {
        map.cell(position.file, _5) = true;
    }

    return map;
}
