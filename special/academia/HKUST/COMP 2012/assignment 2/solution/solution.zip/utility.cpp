#include <iostream>
#include "utility.h"
using namespace std;

ostream& operator<<(ostream& os, const Position& pos)
{
    os << static_cast<char>(pos.file + 'a') << static_cast<char>(pos.rank + '1');
    return os;
}

bool Position::operator==(const Position& pos) const
{
    return (file == pos.file && rank == pos.rank);
}

Position Vector::operator+(const Position& pos) const {
    int newFile = file + static_cast<int>(pos.file);
    int newRank = rank + static_cast<int>(pos.rank);

    if ((newFile < static_cast<int>(_1)) || (newFile > static_cast<int>(_8)) ||
        (newRank < static_cast<int>(_A)) || (newRank > static_cast<int>(_H)))
        return pos;
    
    return Position{static_cast<_FILE>(newFile), static_cast<_RANK>(newRank)};
}

Vector Vector::operator*(int mul) const {
    return Vector{file * mul, rank * mul};
}

BooleanMap& BooleanMap::operator|=(const BooleanMap& other) {
    for (_RANK r = _8; r >= _1; r = static_cast<_RANK>(r-1)) {
        for (_FILE f = _A; f <= _H; f = static_cast<_FILE>(f+1)) {
            cell(f, r) = cell(f, r) || other.cell(f, r);
        }
    }
    return (*this);
}

BooleanMap& BooleanMap::operator&=(const BooleanMap& other) {
    for (_RANK r = _8; r >= _1; r = static_cast<_RANK>(r-1)) {
        for (_FILE f = _A; f <= _H; f = static_cast<_FILE>(f+1)) {
            cell(f, r) = cell(f, r) && other.cell(f, r);
        }
    }
    return (*this);
}

BooleanMap BooleanMap::operator~() const {
    BooleanMap ret;
    for (_RANK r = _8; r >= _1; r = static_cast<_RANK>(r-1)) {
        for (_FILE f = _A; f <= _H; f = static_cast<_FILE>(f+1)) {
            ret.cell(f, r) = !cell(f, r);
        }
    }
    return ret;
}

