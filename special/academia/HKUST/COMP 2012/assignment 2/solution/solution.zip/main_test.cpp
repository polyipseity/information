#include <iostream>
#include <string>
#include "board.h"
#include "userPiece.h"
using namespace std;

#include "taskProgress.h"

#ifdef TASK5_BOARD_FUNC_COMPLETE
#include "userBoard.h"

Piece* getPromotionPiece(Color color) {
    return new Knight(color);
}
#endif

ostream& operator<<(ostream& os, const Vector& v) {
    os << "Vector{" << v.file << ", " << v.rank << "}";
    return os;
}

ostream& operator<<(ostream& os, const BooleanMap& m) {
    os << endl;
    for (int i=0; i<4*NUM_FILES+1; ++i) 
        os << '-';
    os << endl;

    int rankNum = 8;
    for (_RANK r = _8; r >= _1; r = static_cast<_RANK>(r-1)) {
        for (_FILE f = _A; f <= _H; f = static_cast<_FILE>(f+1)) {
            os << '|';
            os << ' ';
            os << (m.cell(f, r) ? '.' : ' ');
            os << ' ';
        }
        os << "| " << rankNum-- << endl;
        for (int i=0; i<4*NUM_FILES+1; ++i) 
            os << '-';
        os << endl;
    }

    char fileChar = 'a';
    for (_FILE f = _A; f <= _H; f = static_cast<_FILE>(f+1)) {
        os << "  " << fileChar++ << ' ';
    }
    return os;
}

// A dummy piece that moves to e8 only
// For testing Board class
class DummyPiece : public Piece {
    private:
        virtual char name() const override { return 'X'; }
    
    public:
        DummyPiece(Color color): Piece(color) {}
        virtual Piece* clone() const override { return new DummyPiece{*this}; }

        virtual BooleanMap getMoves(const Board& board) const override { 
            BooleanMap map{};
            map.cell(_E, _8) = true;
            return map; 
        }
};

Position strToPosition(const string& str) {
    char file = str[0];
    char rank = str[1];
    return Position{static_cast<_FILE>(file - 'a'), static_cast<_RANK>(rank - '1')};
}

class BoardTester {
    private:
        Board board;
#ifdef TASK5_BOARD_FUNC_COMPLETE
        WesternBoard westernBoard;
#endif

    public:
        void runTestCase(int testNum) {
            switch (testNum) {
#ifdef TASK1_UTILITY_COMPLETE
    #define TEST(X) case X: test##X(); break
    #define HIDDEN(X) case (X + 36): hiddentest##X(); break
#else
    #define TEST(X) case X: cout << "Unimplemented task." << endl; break
    #define HIDDEN(X) case (X + 36): cout << "Unimplemented task." << endl; break
#endif
                TEST(1); TEST(2); TEST(3); TEST(4); TEST(5); TEST(6); TEST(7); TEST(8); TEST(9);
                HIDDEN(1); HIDDEN(2); HIDDEN(3); HIDDEN(4); HIDDEN(5); HIDDEN(6);
            #undef TEST
            #undef HIDDEN
#ifdef TASK2_BOARD_COMPLETE
    #define TEST(X) case X: test##X(); break
    #define HIDDEN(X) case (X + 36): hiddentest##X(); break
#else
    #define TEST(X) case X: cout << "Unimplemented task." << endl; break
    #define HIDDEN(X) case (X + 36): cout << "Unimplemented task." << endl; break
#endif
                TEST(10); TEST(11);
                HIDDEN(7); HIDDEN(8); HIDDEN(9);
            #undef TEST
            #undef HIDDEN
#ifdef TASK3_1_LEAPER_COMPLETE
    #define TEST(X) case X: test##X(); break
    #define HIDDEN(X) case (X + 36): hiddentest##X(); break
#else
    #define TEST(X) case X: cout << "Unimplemented task." << endl; break
    #define HIDDEN(X) case (X + 36): cout << "Unimplemented task." << endl; break
#endif
                TEST(12); TEST(13);
                HIDDEN(10); HIDDEN(11);
            #undef TEST
            #undef HIDDEN
#ifdef TASK3_2_RIDER_COMPLETE
    #define TEST(X) case X: test##X(); break
    #define HIDDEN(X) case (X + 36): hiddentest##X(); break
#else
    #define TEST(X) case X: cout << "Unimplemented task." << endl; break
    #define HIDDEN(X) case (X + 36): cout << "Unimplemented task." << endl; break
#endif
                TEST(14); TEST(15); TEST(16);
                HIDDEN(12); HIDDEN(13); HIDDEN(14);
            #undef TEST
            #undef HIDDEN
#ifdef TASK3_3_COMPOUND_COMPLETE
    #define TEST(X) case X: test##X(); break
    #define HIDDEN(X) case (X + 36): hiddentest##X(); break
#else
    #define TEST(X) case X: cout << "Unimplemented task." << endl; break
    #define HIDDEN(X) case (X + 36): cout << "Unimplemented task." << endl; break
#endif
                TEST(17);
                HIDDEN(15); HIDDEN(16); HIDDEN(17);
            #undef TEST
            #undef HIDDEN
#ifdef TASK3_4_DIVERGENT_COMPLETE
    #define TEST(X) case X: test##X(); break
    #define HIDDEN(X) case (X + 36): hiddentest##X(); break
#else
    #define TEST(X) case X: cout << "Unimplemented task." << endl; break
    #define HIDDEN(X) case (X + 36): cout << "Unimplemented task." << endl; break
#endif
                TEST(18); TEST(19);
                HIDDEN(18);
            #undef TEST
            #undef HIDDEN
#if defined(TASK3_3_COMPOUND_COMPLETE) & defined(TASK3_4_DIVERGENT_COMPLETE)
    #define TEST(X) case X: test##X(); break
    #define HIDDEN(X) case (X + 36): hiddentest##X(); break
#else
    #define TEST(X) case X: cout << "Unimplemented task." << endl; break
    #define HIDDEN(X) case (X + 36): cout << "Unimplemented task." << endl; break
#endif
                TEST(20);
                HIDDEN(19); HIDDEN(20);
            #undef TEST
            #undef HIDDEN
#ifdef TASK4_1_2_PIECES_COMPLETE
    #define TEST(X) case X: test##X(); break
    #define HIDDEN(X) case (X + 36): hiddentest##X(); break
#else
    #define TEST(X) case X: cout << "Unimplemented task." << endl; break
    #define HIDDEN(X) case (X + 36): cout << "Unimplemented task." << endl; break
#endif
                TEST(21); TEST(22); TEST(23); TEST(24);
                HIDDEN(21); HIDDEN(22);
#if defined(TASK3_3_COMPOUND_COMPLETE) & defined(TASK3_4_DIVERGENT_COMPLETE)
                HIDDEN(37); HIDDEN(38); HIDDEN(39); HIDDEN(40); HIDDEN(41); HIDDEN(42); HIDDEN(43); HIDDEN(44);
#endif
            #undef TEST
            #undef HIDDEN
#ifdef TASK4_3_PAWN_COMPLETE
    #define TEST(X) case X: test##X(); break
    #define HIDDEN(X) case (X + 36): hiddentest##X(); break
#else
    #define TEST(X) case X: cout << "Unimplemented task." << endl; break
    #define HIDDEN(X) case (X + 36): cout << "Unimplemented task." << endl; break
#endif
                TEST(25); TEST(26);
                HIDDEN(23); HIDDEN(24); HIDDEN(25); HIDDEN(26);
            #undef TEST
            #undef HIDDEN
#ifdef TASK5_BOARD_FUNC_COMPLETE
    #define TEST(X) case X: test##X(); break
    #define HIDDEN(X) case (X + 36): hiddentest##X(); break
#else
    #define TEST(X) case X: cout << "Unimplemented task." << endl; break
    #define HIDDEN(X) case (X + 36): cout << "Unimplemented task." << endl; break
#endif
                TEST(27); TEST(28); TEST(29); TEST(30); TEST(31); TEST(32); TEST(33); TEST(34); TEST(35); TEST(36);
                HIDDEN(27); HIDDEN(28); HIDDEN(29); HIDDEN(30); HIDDEN(31); HIDDEN(32); HIDDEN(33); HIDDEN(34); HIDDEN(35); HIDDEN(36);
            #undef TEST
            #undef HIDDEN
                default:
                    cout << "Unrecognized test case." << endl;
                    break;
            }
        }

#ifdef TASK1_UTILITY_COMPLETE
        void test1() {
            cout << "e4 == e4: " << (Position{_E, _4} == Position{_E, _4}) << endl;
        }

        void hiddentest1() {
            cout << "e4 == f4: " << (Position{_E, _4} == Position{_F, _4}) << endl;
        }

        void test2() {
            cout << "Vector{1, 2} + c3 = " << (Vector{1, 2} + Position{_C, _3}) << endl;
        }

        void test3() {
            cout << "Vector{-2, 0} + g5 = " << (Vector{-2, 0} + Position{_G, _5}) << endl;
        }

        void test4() {
            cout << "Vector{3, 1} + h1 = " << (Vector{3, 1} + Position{_H, _1}) << endl;
        }

        void hiddentest2() {
            cout << "Vector{-4, -4} + e5 = " << (Vector{-4, -4} + Position{_E, _5}) << endl;
        }

        void test5() {
            cout << "Vector{1, 2} * 2 = " << (Vector{1, 2} * 2) << endl;
        }

        void test6() {
            cout << "Vector{-3, 1} * -3 = " << (Vector{-3, 1} * -3) << endl;
        }

        void hiddentest3() {
            cout << "Vector{-1, -5} * 0 = " << (Vector{-1, -5} * 0) << endl;
        }

        void test7() {
            BooleanMap map1 {};
            for (int i=0; i<64; i+=3) map1.cell(static_cast<_FILE>(i/8), static_cast<_RANK>(i%8)) = true;
            cout << "Map 1: " << map1 << endl;

            BooleanMap map2 {};
            for (int i=0; i<64; i+=4) map2.cell(static_cast<_FILE>(i/8), static_cast<_RANK>(i%8)) = true;
            cout << "Map 2: " << map2 << endl;
            
            map1 |= map2;
            cout << "Map 1 bitwise-OR Map 2: " << map1 << endl;
        }

        void hiddentest4() {
            BooleanMap map1 {};
            for (int i=1; i<64; i+=3) map1.cell(static_cast<_FILE>(i/8), static_cast<_RANK>(i%8)) = true;
            cout << "Map 1: " << map1 << endl;

            BooleanMap map2 {};
            for (int i=2; i<64; i+=5) map2.cell(static_cast<_FILE>(i/8), static_cast<_RANK>(i%8)) = true;
            cout << "Map 2: " << map2 << endl;
            
            map1 |= map2;
            cout << "Map 1 bitwise-OR Map 2: " << map1 << endl;
        }

        void test8() {
            BooleanMap map1 {};
            for (int i=0; i<64; i+=3) map1.cell(static_cast<_FILE>(i/8), static_cast<_RANK>(i%8)) = true;
            cout << "Map 1: " << map1 << endl;

            BooleanMap map2 {};
            for (int i=0; i<64; i+=4) map2.cell(static_cast<_FILE>(i/8), static_cast<_RANK>(i%8)) = true;
            cout << "Map 2: " << map2 << endl;
            
            map1 &= map2;
            cout << "Map 1 bitwise-AND Map 2: " << map1 << endl;
        }

        void hiddentest5() {
            BooleanMap map1 {};
            for (int i=1; i<64; i+=3) map1.cell(static_cast<_FILE>(i/8), static_cast<_RANK>(i%8)) = true;
            cout << "Map 1: " << map1 << endl;

            BooleanMap map2 {};
            for (int i=2; i<64; i+=5) map2.cell(static_cast<_FILE>(i/8), static_cast<_RANK>(i%8)) = true;
            cout << "Map 2: " << map2 << endl;
            
            map1 &= map2;
            cout << "Map 1 bitwise-AND Map 2: " << map1 << endl;
        }

        void test9() {
            BooleanMap map1 {};
            for (int i=0; i<64; i+=3) map1.cell(static_cast<_FILE>(i/8), static_cast<_RANK>(i%8)) = true;
            cout << "Map 1: " << map1 << endl;
            
            map1 = ~map1;
            cout << "Bitwise-NOT Map 1: " << map1 << endl;
        }

        void hiddentest6() {
            BooleanMap map1 {};
            for (int i=1; i<64; i+=3) map1.cell(static_cast<_FILE>(i/8), static_cast<_RANK>(i%8)) = true;
            cout << "Map 1: " << map1 << endl;

            map1 = ~map1;
            cout << "Bitwise-NOT Map 1: " << map1 << endl;
        }
#endif

#ifdef TASK2_BOARD_COMPLETE
        void test10() {
            board.addPiece(new DummyPiece(WHITE), Position{_D, _4});
            board.display();
        }

        void test11() {
            board.addPiece(new DummyPiece(WHITE), Position{_D, _4});
            Board board2 = board;
            board2.display();
        }

        void hiddentest7() {
            board.addPiece(new DummyPiece(WHITE), Position{_D, _4});
            board.select(Position{_D, _4});
            Board board2 = board;
            cout << "Copied board's selected position: " << board2.selectedPiece->getPosition() << endl;
        }

        void hiddentest8() {
            board.addPiece(new DummyPiece(WHITE), Position{_D, _4});
            board.select(Position{_D, _4});
            Board board2 = board;
            cout << "Copied board's moveMap: " << board2.moveMap << endl;
        }

        void hiddentest9() {
            board.addPiece(new DummyPiece(WHITE), Position{_D, _4});
            board.royalPieces[WHITE] = board.piece(Position{_D, _4});
            Board board2 = board;
            cout << "Copied board's royal piece position: " << board2.royalPieces[WHITE]->getPosition() << endl;
        }
#endif
        
#ifdef TASK3_1_LEAPER_COMPLETE
        void test12() {
            board.addPiece(new Leaper<'N', 2, 1>(WHITE), Position{_D, _4});
            board.select(Position{_D, _4});
            board.display();
        }

        void test13() {
            board.addPiece(new Leaper<'N', 2, 1>(BLACK), Position{_D, _4});
            board.isWhiteTurn = false;
            board.select(Position{_D, _4});
            board.display();
        }

        void hiddentest10() {
            board.addPiece(new Leaper<'N', 2, 1>(WHITE), Position{_G, _7});
            board.select(Position{_G, _7});
            board.display();
        }

        void hiddentest11() {
            board.addPiece(new Leaper<'N', -3, 2>(BLACK), Position{_F, _4});
            board.isWhiteTurn = false;
            board.select(Position{_F, _4});
            board.display();
        }
#endif
        
#ifdef TASK3_2_RIDER_COMPLETE
        void test14() {
            board.addPiece(new Rider<'R', 1, 0>(WHITE), Position{_D, _4});
            board.select(Position{_D, _4});
            board.display();
        }

        void test15() {
            board.addPiece(new Rider<'R', 0, 2, 2>(WHITE), Position{_D, _1});
            board.select(Position{_D, _1});
            board.display();
        }

        void test16() {
            board.addPiece(new Rider<'R', 1, 0>(WHITE), Position{_C, _5});
            board.addPiece(new Rider<'N', 1, 0>(BLACK), Position{_G, _5});
            board.select(Position{_C, _5});
            board.display();
        }

        void hiddentest12() {
            board.addPiece(new Rider<'R', 0, 2, 2>(WHITE), Position{_D, _1});
            board.addPiece(new Rider<'N', 1, 0>(BLACK), Position{_D, _4});
            board.select(Position{_D, _1});
            board.display();
        }

        void hiddentest13() {
            board.addPiece(new Rider<'R', -1, 1>(BLACK), Position{_A, _8});
            board.isWhiteTurn = false;
            board.select(Position{_A, _8});
            board.display();
        }

        void hiddentest14() {
            board.addPiece(new Rider<'R', 1, 1, 3>(WHITE), Position{_C, _3});
            board.addPiece(new Rider<'N', 1, 0>(BLACK), Position{_G, _7});
            board.select(Position{_C, _3});
            board.display();
        }
#endif
        
#ifdef TASK3_3_COMPOUND_COMPLETE
        void test17() {
            board.addPiece(new Compound<'C', Leaper<'N', 2, 1>, Rider<'R', 1, 0>>(WHITE), Position{_D, _4});
            board.select(Position{_D, _4});
            board.display();
        }

        void hiddentest15() {
            board.addPiece(new Compound<'C', Leaper<'N', 2, 1>, Rider<'R', 1, 0>>(WHITE), Position{_D, _4});
            board.addPiece(new Leaper<'N', 1, 0>(BLACK), Position{_F, _5});
            board.addPiece(new Leaper<'N', 1, 0>(BLACK), Position{_G, _4});
            board.select(Position{_D, _4});
            board.display();
        }

        void hiddentest16() {
            board.addPiece(new Compound<'C', Rider<'R', -1, 1, 2>, Rider<'R', 1, 0>>(WHITE), Position{_D, _4});
            board.select(Position{_D, _4});
            board.display();
        }

        void hiddentest17() {
            board.addPiece(new Compound<'C', Leaper<'N', 1, -2>, Leaper<'N', 1, -2>>(WHITE), Position{_D, _4});
            board.select(Position{_D, _4});
            board.display();
        }
#endif
        
#ifdef TASK3_4_DIVERGENT_COMPLETE
        void test18() {
            board.addPiece(new Divergent<'D', Leaper<'N', 2, 1>, Rider<'R', 1, 0>>(WHITE), Position{_D, _4});
            board.addPiece(new Leaper<'N', 1, 0>(BLACK), Position{_G, _4});
            board.select(Position{_D, _4});
            board.display();
        }

        void test19() {
            board.addPiece(new Divergent<'D', Rider<'R', 1, 0>, Leaper<'N', 2, 1>>(WHITE), Position{_D, _4});
            board.addPiece(new Leaper<'N', 1, 0>(BLACK), Position{_G, _4});
            board.select(Position{_D, _4});
            board.display();
        }

        void hiddentest18() {
            board.addPiece(new Divergent<'D', Rider<'R', -1, 1, 2>, Rider<'R', 1, 0>>(WHITE), Position{_D, _4});
            board.addPiece(new Leaper<'N', 1, 0>(BLACK), Position{_F, _4});
            board.select(Position{_D, _4});
            board.display();
        }
#endif
        
#if defined(TASK3_3_COMPOUND_COMPLETE) & defined(TASK3_4_DIVERGENT_COMPLETE)
        void test20() {
            board.addPiece(new Divergent<'D', Compound<'C', Leaper<'N', 2, 1>, Rider<'R', 1, 0>>, Compound<'C', Leaper<'N', -2, 1>, Rider<'R', 0, -1>>>(WHITE), Position{_D, _4});
            board.addPiece(new Leaper<'N', 1, 0>(BLACK), Position{_G, _4});
            board.addPiece(new Leaper<'N', 1, 0>(BLACK), Position{_F, _5});
            board.addPiece(new Leaper<'N', 1, 0>(BLACK), Position{_D, _2});
            board.addPiece(new Leaper<'N', 1, 0>(BLACK), Position{_B, _5});
            board.select(Position{_D, _4});
            board.display();
        }

        void hiddentest19() {
            board.addPiece(new Compound<'C', Divergent<'D', Leaper<'N', 2, 1>, Rider<'R', 1, 0>>, Divergent<'D', Leaper<'N', -2, 1>, Rider<'R', 0, -1>>>(WHITE), Position{_D, _4});
            board.addPiece(new Leaper<'N', 1, 0>(BLACK), Position{_G, _4});
            board.addPiece(new Leaper<'N', 1, 0>(BLACK), Position{_F, _5});
            board.addPiece(new Leaper<'N', 1, 0>(BLACK), Position{_D, _2});
            board.addPiece(new Leaper<'N', 1, 0>(BLACK), Position{_B, _5});
            board.select(Position{_D, _4});
            board.display();
        }

        void hiddentest20() {
            board.addPiece(new Divergent<'D', OmniRider<'R', 1, 0>, OmniLeaper<'N', 2, 1>>(WHITE), Position{_D, _4});
            board.addPiece(new Leaper<'N', 1, 0>(BLACK), Position{_G, _4});
            board.addPiece(new Leaper<'N', 1, 0>(BLACK), Position{_F, _5});
            board.addPiece(new Leaper<'N', 1, 0>(BLACK), Position{_D, _2});
            board.addPiece(new Leaper<'N', 1, 0>(BLACK), Position{_B, _5});
            board.select(Position{_D, _4});
            board.display();
        }
#endif
        
#ifdef TASK4_1_2_PIECES_COMPLETE
        void test21() {
            board.addPiece(new Bishop(WHITE), Position{_D, _4});
            board.addPiece(new Knight(WHITE), Position{_F, _2});
            board.addPiece(new Knight(BLACK), Position{_F, _6});
            board.select(Position{_D, _4});
            board.display();
        }

        void test22() {
            board.addPiece(new Queen(WHITE), Position{_D, _4});
            board.addPiece(new Knight(WHITE), Position{_B, _2});
            board.addPiece(new Knight(BLACK), Position{_F, _4});
            board.select(Position{_D, _4});
            board.display();
        }

        void test23() {
            board.addPiece(new King(WHITE), Position{_D, _4});
            board.addPiece(new Knight(WHITE), Position{_D, _3});
            board.addPiece(new DummyPiece(BLACK), Position{_E, _5});
            board.select(Position{_D, _4});
            board.display();
        }

        void test24() {
            King kingPiece {WHITE};
            cout << "King is royal: " << isRoyal(&kingPiece) << endl;
        }

        void hiddentest21() {
            board.addPiece(new King(WHITE), Position{_D, _8});
            board.select(Position{_D, _8});
            board.display();
        }

        void hiddentest22() {
            Knight knightPiece {WHITE};
            cout << "Knight is royal: " << isRoyal(&knightPiece) << endl;
        }
#endif
        
#ifdef TASK4_3_PAWN_COMPLETE
        void test25() {
            board.addPiece(new Pawn(WHITE), Position{_D, _2});
            board.addPiece(new Pawn(BLACK), Position{_E, _3});
            board.select(Position{_D, _2});
            board.display();
        }

        void test26() {
            board.addPiece(new Pawn(WHITE), Position{_D, _3});
            board.addPiece(new Pawn(BLACK), Position{_C, _4});
            board.select(Position{_D, _3});
            board.display();
        }

        void hiddentest23() {
            board.addPiece(new Pawn(BLACK), Position{_D, _7});
            board.addPiece(new Pawn(BLACK), Position{_E, _6});
            board.isWhiteTurn = false;
            board.select(Position{_D, _7});
            board.display();
        }

        void hiddentest24() {
            board.addPiece(new Pawn(BLACK), Position{_D, _7});
            board.addPiece(new Pawn(BLACK), Position{_D, _6});
            board.addPiece(new Pawn(WHITE), Position{_C, _6});
            board.addPiece(new Pawn(WHITE), Position{_E, _6});
            board.isWhiteTurn = false;
            board.select(Position{_D, _7});
            board.display();
        }

        void hiddentest25() {
            board.addPiece(new Pawn(BLACK), Position{_D, _7});
            board.addPiece(new Pawn(BLACK), Position{_D, _5});
            board.isWhiteTurn = false;
            board.select(Position{_D, _7});
            board.display();
        }

        void hiddentest26() {
            board.addPiece(new Pawn(WHITE), Position{_A, _7});
            board.addPiece(new Rook(BLACK), Position{_B, _8});
            board.addPiece(new Knight(BLACK), Position{_B, _6});
            board.select(Position{_A, _7});
            board.display();
        }
#endif

#ifdef TASK5_BOARD_FUNC_COMPLETE
        void task5setup(Color color) {
            board.addPiece(new Rook(WHITE), Position{_E, _3});
            board.addPiece(new King(WHITE), Position{_G, _3});
            board.addPiece(new Knight(WHITE), Position{_C, _5});
            board.addPiece(new Queen(BLACK), Position{_B, _3});
            board.addPiece(new Bishop(BLACK), Position{_B, _8});
            board.addPiece(new Pawn(BLACK), Position{_C, _7});
            board.isWhiteTurn = (color == WHITE);
        }

        void test27() {
            task5setup(WHITE);
            board.select(Position{_C, _5});
            board.display();
            board.select(Position{_E, _4});
            board.display();
        }

        void test28() {
            task5setup(BLACK);
            board.select(Position{_B, _3});
            board.display();
            board.select(Position{_E, _3});
            board.display();
        }

        void hiddentest27() {
            task5setup(WHITE);
            board.select(Position{_C, _5});
            board.select(Position{_B, _3});
            cout << "Current turn: " << (board.isWhiteTurn ? "White" : "Black") << endl;
        }

        void hiddentest28() {
            task5setup(WHITE);
            board.select(Position{_C, _5});
            board.select(Position{_D, _3});
            board.select(Position{_B, _3});
            board.select(Position{_D, _3});
            board.display();
        }

        void test29() {
            task5setup(WHITE);
            cout << "White's attacking map: " << board.getAttackingMap() << endl;
        }

        void hiddentest29() {
            task5setup(BLACK);
            cout << "Black's attacking map: " << board.getAttackingMap() << endl;
        }

        void hiddentest30() {
            task5setup(WHITE);
            board.addPiece(new Knight(BLACK), Position{_H, _2});
            board.addPiece(new King(BLACK), Position{_E, _8});
            cout << "White's attacking map: " << board.getAttackingMap() << endl;
        }

        void hiddentest31() {
            task5setup(BLACK);
            board.addPiece(new Bishop(WHITE), Position{_D, _6});
            cout << "Black's attacking map: " << board.getAttackingMap() << endl;
        }

        void test30() {
            task5setup(WHITE);
            board.select(Position{_E, _3});
            board.display();
        }

        void test31() {
            task5setup(BLACK);
            board.select(Position{_C, _7});
            board.select(Position{_C, _6});
            board.select(Position{_G, _3});
            board.display();
        }

        void hiddentest32() {
            task5setup(WHITE);
            board.select(Position{_E, _3});
            board.select(Position{_E, _6});
            board.display();
        }

        void hiddentest33() {
            task5setup(BLACK);
            board.select(Position{_C, _7});
            board.select(Position{_C, _6});
            board.select(Position{_E, _3});
            board.display();
        }

        void testOpening(initializer_list<pair<string, string>> moves) {
            westernBoard.addPiece(new Rook(WHITE), Position{_A, _1});
            westernBoard.addPiece(new Knight(WHITE), Position{_B, _1});
            westernBoard.addPiece(new Bishop(WHITE), Position{_C, _1});
            westernBoard.addPiece(new Queen(WHITE), Position{_D, _1});
            westernBoard.addPiece(new King(WHITE), Position{_E, _1});
            westernBoard.addPiece(new Bishop(WHITE), Position{_F, _1});
            westernBoard.addPiece(new Knight(WHITE), Position{_G, _1});
            westernBoard.addPiece(new Rook(WHITE), Position{_H, _1});

            westernBoard.addPiece(new Pawn(WHITE), Position{_A, _2});
            westernBoard.addPiece(new Pawn(WHITE), Position{_B, _2});
            westernBoard.addPiece(new Pawn(WHITE), Position{_C, _2});
            westernBoard.addPiece(new Pawn(WHITE), Position{_D, _2});
            westernBoard.addPiece(new Pawn(WHITE), Position{_E, _2});
            westernBoard.addPiece(new Pawn(WHITE), Position{_F, _2});
            westernBoard.addPiece(new Pawn(WHITE), Position{_G, _2});
            westernBoard.addPiece(new Pawn(WHITE), Position{_H, _2});

            westernBoard.addPiece(new Pawn(BLACK), Position{_A, _7});
            westernBoard.addPiece(new Pawn(BLACK), Position{_B, _7});
            westernBoard.addPiece(new Pawn(BLACK), Position{_C, _7});
            westernBoard.addPiece(new Pawn(BLACK), Position{_D, _7});
            westernBoard.addPiece(new Pawn(BLACK), Position{_E, _7});
            westernBoard.addPiece(new Pawn(BLACK), Position{_F, _7});
            westernBoard.addPiece(new Pawn(BLACK), Position{_G, _7});
            westernBoard.addPiece(new Pawn(BLACK), Position{_H, _7});

            westernBoard.addPiece(new Rook(BLACK), Position{_A, _8});
            westernBoard.addPiece(new Knight(BLACK), Position{_B, _8});
            westernBoard.addPiece(new Bishop(BLACK), Position{_C, _8});
            westernBoard.addPiece(new Queen(BLACK), Position{_D, _8});
            westernBoard.addPiece(new King(BLACK), Position{_E, _8});
            westernBoard.addPiece(new Bishop(BLACK), Position{_F, _8});
            westernBoard.addPiece(new Knight(BLACK), Position{_G, _8});
            westernBoard.addPiece(new Rook(BLACK), Position{_H, _8});

            for (pair<string, string> move : moves) {
                // Uncomment the following line if you need to debug move-by-move
                // westernBoard.display();

                westernBoard.select(strToPosition(move.first));
                westernBoard.select(strToPosition(move.second));
            }

            westernBoard.display();
        }

        #define MOVE(start, dest) make_pair(#start, #dest)
        #define MOVE_WRONG(start, wrong, dest) make_pair(#start, #wrong), make_pair(#wrong, #dest)

        void test32() {
            testOpening({
                MOVE(e2, e4), MOVE(e7, e5), 
                MOVE(g1, f3), MOVE(b8, c6),
                MOVE(f1, b5), MOVE(g8, f6),
            });
        }

        void test33() {
            testOpening({
                MOVE(d2, d4), MOVE(d7, d5), 
                MOVE(c2, c4), MOVE(d5, c4),
                MOVE(e2, e4), MOVE(e7, e5),
                MOVE(f1, c4),
            });
        }

        void test34() {
            testOpening({
                MOVE(e2, e4), MOVE(e7, e5), 
                MOVE(d1, h5), MOVE(b8, c6),
                MOVE(f1, c4), MOVE(g8, f6),
                MOVE(h5, f7),
            });
        }

        void test35() {
            testOpening({
                MOVE(d2, d4), MOVE(d7, d5), 
                MOVE(c1, f4), MOVE(g8, f6),
                MOVE(e2, e3), MOVE(c7, c5),
                MOVE(f4, b8), MOVE(a8, b8),
                MOVE(f1, b5), MOVE(c8, d7),
            });
        }

        void test36() {
            testOpening({
                MOVE(d2, d4), MOVE(d7, d5), 
                MOVE(c2, c4), MOVE(e7, e5),
                MOVE(d4, e5), MOVE(d5, d4),
                MOVE(e2, e3), MOVE(f8, b4),
                MOVE(c1, d2), MOVE(d4, e3),
                MOVE(d2, b4), MOVE(e3, f2),
                MOVE(e1, e2), MOVE(f2, g1),
            });
        }

        void hiddentest34() {
            testOpening({
                MOVE(d2, d4), MOVE(g8, f6),
                MOVE(c2, c4), MOVE(g7, g6),
                MOVE(b1, c3), MOVE(f8, g7),
                MOVE(c1, g5), MOVE(e8, g8),
                MOVE(d1, d2), MOVE(f8, e8),
                MOVE(e1, c1), MOVE_WRONG(f7, f5, f7), MOVE(b7, b5), 
            });
        }

        void hiddentest35() {
            testOpening({
                MOVE(e2, e4), MOVE(e7, e6), 
                MOVE(d2, d4), MOVE(d7, d5),
                MOVE(e4, e5), MOVE(c7, c5),
                MOVE(c2, c3), MOVE(f7, f5),
                MOVE(e5, f6), MOVE(g8, f6),
                MOVE(g1, f3), MOVE(b8, c6), 
                MOVE(c1, e3), MOVE_WRONG(f8, h6, d6),
                MOVE(d4, c5), MOVE(b7, b5),
                MOVE(c3, c4), MOVE_WRONG(b5, b3, c4),
                MOVE(c5, d6), MOVE_WRONG(c6, a7, b4),
                MOVE(d1, d4), MOVE(b4, d3),
                MOVE_WRONG(d4, f6, d3),
            });
        }

        void hiddentest36() {
            testOpening({
                MOVE(e2, e4), MOVE(d7, d6), MOVE(d2, d4), MOVE(g8, f6), MOVE(b1, c3), MOVE(g7, g6), MOVE(c1, e3), MOVE(f8, g7), 
                MOVE(d1, d2), MOVE(c7, c6), MOVE(f2, f3), MOVE(b7, b5), MOVE(g1, e2), MOVE(b8, d7), MOVE(e3, h6), MOVE(g7, h6), 
                MOVE(d2, h6), MOVE(c8, b7), MOVE(a2, a3), MOVE(e7, e5), MOVE(e1, c1), MOVE(d8, e7), MOVE(c1, b1), MOVE(a7, a6), 
                MOVE(e2, c1), MOVE(e8, c8), MOVE(c1, b3), MOVE(e5, d4), MOVE(d1, d4), MOVE(c6, c5), MOVE(d4, d1), MOVE(d7, b6), 
                MOVE(g2, g3), MOVE(c8, b8), MOVE(b3, a5), MOVE(b7, a8), MOVE(f1, h3), MOVE(d6, d5), MOVE(h6, f4), MOVE(b8, a7), 
                MOVE(h1, e1), MOVE(d5, d4), MOVE(c3, d5), MOVE(b6, d5), MOVE(e4, d5), MOVE(e7, d6), MOVE(d1, d4), MOVE(c5, d4), 
                MOVE(e1, e7), MOVE(a7, b6), MOVE(f4, d4), MOVE(b6, a5), MOVE(b2, b4), MOVE(a5, a4), MOVE(d4, c3), MOVE(d6, d5), 
                MOVE(e7, a7), MOVE(a8, b7), MOVE(a7, b7), MOVE(d5, c4), MOVE(c3, f6), MOVE(a4, a3), MOVE(f6, a6), MOVE(a3, b4), 
                MOVE(c2, c3), MOVE(b4, c3), MOVE(a6, a1), MOVE(c3, d2), MOVE(a1, b2), MOVE(d2, d1), MOVE(h3, f1), MOVE(d8, d2), 
                MOVE(b7, d7), MOVE(d2, d7), MOVE(f1, c4), MOVE(b5, c4), MOVE(b2, h8), MOVE(d7, d3), MOVE(h8, a8), MOVE(c4, c3), 
                MOVE(a8, a4), MOVE(d1, e1), MOVE(f3, f4), MOVE(f7, f5), MOVE(b1, c1), MOVE(d3, d2), MOVE(a4, a7),
            });
        }
#endif
        
#if defined(TASK3_3_COMPOUND_COMPLETE) & defined(TASK3_4_DIVERGENT_COMPLETE) & defined(TASK4_1_2_PIECES_COMPLETE)
        void hiddentest37() {
            using Archbishop = Compound<'A', Bishop, Knight>;
            board.addPiece(new Archbishop(WHITE), Position{_D, _4});
            board.select(Position{_D, _4});
            board.display();
        }

        void hiddentest38() {
            using Chancellor = Compound<'C', Rook, Knight>;
            board.addPiece(new Chancellor(WHITE), Position{_D, _4});
            board.select(Position{_D, _4});
            board.display();
        }

        void hiddentest39() {
            using Dabbaba = OmniLeaper<'D', 2, 0>;
            board.addPiece(new Dabbaba(WHITE), Position{_D, _4});
            board.addPiece(new Knight(BLACK), Position{_E, _4});
            board.select(Position{_D, _4});
            board.display();
        }

        void hiddentest40() {
            using Elephant = Divergent<'E', Bishop, Knight>;
            board.addPiece(new Elephant(WHITE), Position{_D, _4});
            board.addPiece(new Knight(BLACK), Position{_F, _6});
            board.addPiece(new Knight(BLACK), Position{_B, _5});
            board.select(Position{_D, _4});
            board.display();
        }

        void hiddentest41() {
            using Hare = Divergent<'H', Knight, Bishop>;
            board.addPiece(new Hare(WHITE), Position{_D, _4});
            board.addPiece(new Knight(BLACK), Position{_G, _7});
            board.addPiece(new Knight(BLACK), Position{_B, _5});
            board.select(Position{_D, _4});
            board.display();
        }

        void hiddentest42() {
            using Lance = Rider<'L', 0, 1>;
            board.addPiece(new Lance(WHITE), Position{_D, _3});
            board.select(Position{_D, _3});
            board.display();
        }

        void hiddentest43() {
            using Nightrider = OmniRider<'M', 2, 1>;
            board.addPiece(new Nightrider(WHITE), Position{_B, _3});
            board.select(Position{_B, _3});
            board.display();
        }

        void hiddentest44() {
            using SilverGeneral = Compound<'S', OmniLeaper<'S', 1, 1>, Leaper<'S', 0, 1>>;
            board.addPiece(new SilverGeneral(WHITE), Position{_D, _4});
            board.select(Position{_D, _4});
            board.display();
        }
#endif

};

int main() {
    BoardTester tester;
    cout << boolalpha;
    int test;
    cin >> test;
    tester.runTestCase(test);
}
