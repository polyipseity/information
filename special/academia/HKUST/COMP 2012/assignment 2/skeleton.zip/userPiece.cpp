#include "userPiece.h"

// TASK 4.2: isRoyal(const Piece*)
// TODO



// TASK 4.3: Implement any Pawn function(s) here if needed

