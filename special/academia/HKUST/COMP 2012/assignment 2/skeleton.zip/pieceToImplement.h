// TASK 3: Implement the 4 Piece-derived classes here
// All classes will inherit the NamedPiece class 
// and implement the remaining pure virtual functions


// TODO 3.1: Leaper class



// TODO 3.2: Rider class



// TODO 3.3: Compound class



// TODO 3.4: Divergent class

