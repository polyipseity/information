#include "studentlist.h"

void StudentList::addStudent(const string& name, int SID, const string& department, int year) {
    if (numStudents == CLASS_CAPACITY) return;
    students[numStudents++] = {name, SID, department, year};
}

void StudentList::setStudentGrade(int SID, const CourseGrade& grade) {
    for (int i=0; i<numStudents; ++i) {
        if (students[i].getSID() == SID) {
            students[i].setGrade(grade);
            return;
        }
    }
}

void StudentList::displaySortedName(const string& depFilter, int yearFilter) const {
    cout << "Name\t\tSID\t\tDep\tYr\tTotal" << endl;
    cout << "======================================================" << endl;

    Student sortedStudents[CLASS_CAPACITY];
    for (int i=0; i<numStudents; ++i) 
        sortedStudents[i] = students[i];
    for (int i=0; i<numStudents; ++i) {
        for (int j=i+1; j<numStudents; ++j) {
            if (sortedStudents[i].getName().compare(sortedStudents[j].getName()) > 0) {
                Student temp = sortedStudents[i];
                sortedStudents[i] = sortedStudents[j];
                sortedStudents[j] = temp;
            }
        }
    }

    for (int i=0; i<numStudents; ++i) {
        if ((depFilter == ALL_DEPARTMENTS || depFilter == sortedStudents[i].getDepartment())
            && (yearFilter == ALL_YEARS || yearFilter == sortedStudents[i].getYear())) {
                sortedStudents[i].display();
        }
    }
}

void StudentList::displaySortedGrade(const string& depFilter, int yearFilter) const {
    cout << "Name\t\tSID\t\tDep\tYr\tTotal" << endl;
    cout << "======================================================" << endl;

    Student sortedStudents[CLASS_CAPACITY];
    for (int i=0; i<numStudents; ++i) 
        sortedStudents[i] = students[i];
    for (int i=0; i<numStudents; ++i) {
        for (int j=i+1; j<numStudents; ++j) {
            if (sortedStudents[i].getTotalPercentage() < sortedStudents[j].getTotalPercentage()) {
                Student temp = sortedStudents[i];
                sortedStudents[i] = sortedStudents[j];
                sortedStudents[j] = temp;
            }
        }
    }

    for (int i=0; i<numStudents; ++i) {
        if ((depFilter == ALL_DEPARTMENTS || depFilter == sortedStudents[i].getDepartment())
            && (yearFilter == ALL_YEARS || yearFilter == sortedStudents[i].getYear())) {
                sortedStudents[i].display();
        }
    }
}