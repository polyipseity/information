#include "student.h"

double CourseGrade::getTotalPercentage() const {
    return LAB_PERCENTAGE * labs
        + ASGN_PERCENTAGE * assignments
        + MIDTERM_PERCENTAGE * midtermExam
        + FINAL_PERCENTAGE * finalExam;
}

Student::Student() {
    name = "";
    SID = 0;
    department = "";
    year = 0;
    grade = {0.0, 0.0, 0.0, 0.0};
}

Student::Student(const string& name, int SID, const string& department, int year) {
    this->name = name;
    this->SID = SID;
    this->department = department;
    this->year = year;
    grade = {0.0, 0.0, 0.0, 0.0};
}

void Student::setGrade(const CourseGrade& grade) {
    this->grade = grade;
}

string Student::getName() const { return name; } 
int Student::getSID() const { return SID; }
string Student::getDepartment() const { return department; }
int Student::getYear() const { return year; }
double Student::getTotalPercentage() const { return grade.getTotalPercentage(); }
