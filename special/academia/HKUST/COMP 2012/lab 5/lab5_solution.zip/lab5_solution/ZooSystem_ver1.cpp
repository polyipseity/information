#include "ZooSystem.h"
#include <iostream> 

ZooSystem::ZooSystem(int cap) : capacity(cap), size(0) {
    animals = new Animal*[capacity]; // Allocate memory for pointers
}

ZooSystem::~ZooSystem() {
    for (int i = 0; i < size; ++i) {
        delete animals[i]; // Delete each animal object
    }
    delete[] animals; // Delete array of pointers
}

void ZooSystem::addAnimal(Animal* animal) {
    if (size < capacity) {
        animals[size++] = animal; // Add animal to array
    } else {
        // Handle array being full, maybe resize or ignore
        cout << "Array is full, unable to add animal.\n";
    }
}

void ZooSystem::listAllAnimals() const {
    for (int i = 0; i < size; ++i) {
        animals[i]->describe();
    }
}

void ZooSystem::listCarnivores() const {
    for (int i = 0; i < size; ++i) {
        if (animals[i]->getFoodType() == FoodType::Meat) {
            animals[i]->describe();
        }
    }
}

void ZooSystem::listHerbivores() const {
    for (int i = 0; i < size; ++i) {
        if (animals[i]->getFoodType() == FoodType::Vegetable) {
            animals[i]->describe();
        }
    }
}

double ZooSystem::calculateMeatConsumption() const {
    double totalMeatConsumption = 0;
    for (int i = 0; i < size; ++i) {
        if (animals[i]->getFoodType() == FoodType::Meat) {
            totalMeatConsumption += animals[i]->getFoodPerDay();
        }
    }
    return totalMeatConsumption;
}

double ZooSystem::calculateVegetableConsumption() const {
    double totalVegetableConsumption = 0;
    for (int i = 0; i < size; ++i) {
        if (animals[i]->getFoodType() == FoodType::Vegetable) {
            totalVegetableConsumption += animals[i]->getFoodPerDay();
        }
    }
    return totalVegetableConsumption;
}

// check type_id, dynamic class
// 