#include <iostream>
#include <typeinfo>
#include "ZooSystem.h"

ZooSystem::ZooSystem(int cap) : capacity(cap), size(0) {
    animals = new Animal*[capacity]; // Allocate memory for pointers
}

ZooSystem::~ZooSystem() {
    for (int i = 0; i < size; ++i) {
        delete animals[i]; // Delete each animal object
    }
    delete[] animals; // Delete array of pointers
}

void ZooSystem::addAnimal(Animal* animal) {
    if (size < capacity) {
        animals[size++] = animal; // Add animal to array
    } else {
        std::cout << "Array is full, unable to add animal.\n";
    }
}

void ZooSystem::listAllAnimals() const {
    for (int i = 0; i < size; ++i) {
        std::cout << "Type: " << typeid(*animals[i]).name() << " - ";
        animals[i]->describe();
    }
}

void ZooSystem::listCarnivores() const {
    for (int i = 0; i < size; ++i) {
        Carnivore* carn = dynamic_cast<Carnivore*>(animals[i]);
        if (carn) {  // If the cast is successful, carn is not nullptr
            std::cout << "Carnivore: " << typeid(*carn).name() << " - ";
            carn->describe();
        }
    }
}

void ZooSystem::listHerbivores() const {
    for (int i = 0; i < size; ++i) {
        Herbivore* herb = dynamic_cast<Herbivore*>(animals[i]);
        if (herb) {
            std::cout << "Herbivore: " << typeid(*herb).name() << " - ";
            herb->describe();
        }
    }
}

double ZooSystem::calculateMeatConsumption() const {
    double totalMeatConsumption = 0;
    for (int i = 0; i < size; ++i) {
        Carnivore* carn = dynamic_cast<Carnivore*>(animals[i]);
        if (carn) {
            totalMeatConsumption += carn->getFoodPerDay();
        }
    }
    return totalMeatConsumption;
}

double ZooSystem::calculateVegetableConsumption() const {
    double totalVegetableConsumption = 0;
    for (int i = 0; i < size; ++i) {
        Herbivore* herb = dynamic_cast<Herbivore*>(animals[i]);
        if (herb) {
            totalVegetableConsumption += herb->getFoodPerDay();
        }
    }
    return totalVegetableConsumption;
}
