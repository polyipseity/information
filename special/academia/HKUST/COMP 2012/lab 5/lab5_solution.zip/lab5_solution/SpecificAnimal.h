#include "Animal.h"
using namespace std;

class Lion : public Carnivore {
public:
    Lion(const string& name, int age, double foodPerDay, int teethCount);
    void describe() const override;
};

class Tiger : public Carnivore {
public:
    Tiger(const string& name, int age, double foodPerDay, int teethCount);
    void describe() const override;
};

class Elephant : public Herbivore {
public:
    Elephant(const string& name, int age, double foodPerDay, const string& favoritePlant, const string& habitatPreference);
    void describe() const override;
};