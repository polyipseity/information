#include <iostream>
#include <string>

#ifndef FOODTYPE_H
#define FOODTYPE_H

enum FoodType {
    Meat,
    Vegetable
};

#endif
