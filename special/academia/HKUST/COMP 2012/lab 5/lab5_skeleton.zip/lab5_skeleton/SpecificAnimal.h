#include "Animal.h"

// ======== Carnivore class ========
class Lion : public Carnivore {
// Todo 3.1: Implement the Lion class
};

class Tiger : public Carnivore {
// Todo 3.1: Implement the Tiger class
};


// ======== Herbivore class ========
class Elephant : public Herbivore {
// Todo 3.2: Implement the Elephant class
};

