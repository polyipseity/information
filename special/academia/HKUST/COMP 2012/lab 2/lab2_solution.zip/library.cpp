#include "library.h"

Book::Book(const char* name, const char* author, int publishYear): publishYear(publishYear) {
    this->name = new char[strlen(name) + 1];
    strcpy(this->name, name);
    this->author = new char[strlen(author) + 1];
    strcpy(this->author, author);
}

Book::~Book() {
    delete [] name;
    delete [] author;
}

Bookcase::Bookcase(int capacity): books(new Book*[capacity]), numBooks(0), capacity(capacity) {
    // not actually needed
    for (int i=0; i<capacity; ++i) {
        books[i] = nullptr;
    }
}

Bookcase::~Bookcase() {
    for (int i=0; i<numBooks; ++i) {
        delete books[i];
    }
    delete [] books;
}

void Bookcase::addBook(const char* name, const char* author, int publishYear) {
    if (numBooks >= capacity) {
        cout << "Bookcase is full, cannot add " << name << "!" << endl;
        return;
    }

    books[numBooks++] = new Book(name, author, publishYear);
}

Library::Library(int sciCapacity, int hmnCapacity, int miscCapacity): bookcases{sciCapacity, hmnCapacity, miscCapacity} {}

Library::~Library() {}
