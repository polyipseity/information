#include "Buyer.h"

Buyer::Buyer(int id, const string& name) : buyerID(id), buyerName(name) {}

void Buyer::setBuyerId(int newId) { 
    buyerID = newId; 
}

int Buyer::getBuyerId() const {
    return buyerID;
}

void Buyer::setBuyerName(const string& newName) { 
    this->buyerName = newName; 
}

string Buyer::getBuyerName() const { 
    return buyerName; 
}