#include "OrderList.h"
#include <iostream>
#include <algorithm> // For copy
#include <new>       // For bad_alloc

OrderList::OrderList() : head(nullptr) {}

OrderList::~OrderList() {
  OrderNode* current = head;
  while (current != nullptr) {
    OrderNode* next = current->next;
    delete current;
    current = next;
  }
  head = nullptr;
}

void OrderList::addOrder(const Order& order) {
    OrderNode* newNode = new OrderNode(order);
    if (head == nullptr) {
        head = newNode;
    } else {
        OrderNode* current = head;
        while (current->next != nullptr) {
            current = current->next;
        }
        current->next = newNode;
    }
}

bool OrderList::removeOrder(int orderId) {
    OrderNode* current = head;
    OrderNode* prev = nullptr;
    while (current != nullptr && current->order.getOrderId() != orderId) {
        prev = current;
        current = current->next;
    }
    if (current == nullptr) return false; // Order not found

    if (prev == nullptr) {
        head = current->next; // Remove head
    } else {
        prev->next = current->next; // Bypass the current node
    }
    delete current;
    return true;
}

Order* OrderList::findOrder(int orderId) const {
    OrderNode* current = head;
    while (current != nullptr) {
        if (current->order.getOrderId() == orderId) {
            return &(current->order); // Return a pointer to the order
        }
        current = current->next;
    }
    return nullptr; // Order not found
}

void OrderList::displayOrderList() const {
    cout << "Order List:" << endl;
    
    //TODO for students
    if (head == nullptr) {
        cout << "The order list is empty." << endl;
        return;
    }

    OrderNode* current = head;
    while (current != nullptr) {
        current->order.displayOrder();
        current = current->next;
    }
}

void OrderList::displayOrdersForBuyer(int buyerId) const {
    bool found = false;
    OrderNode* current = head;
    while (current != nullptr) {
        if (current->buyer.getBuyerId() == buyerId) {
            current->order.displayOrder(); // Assuming Order has a method to display itself
            found = true;
        }
        current = current->next;
    }
    if (!found) {
        cout << "No orders found for Buyer ID: " << buyerId << endl;
    }
}

bool OrderList::isEmpty() const {
  return head == nullptr;
}