#include "Order.h"
#include <iostream>

Order::Order(): orderId(0), currentNum(0){}

const Buyer& Order::getBuyer() const {
  return buyer;
}

int Order::getcurrentNum() const {
  return currentNum;
}

void Order::setOrderId(int newId){
  orderId = newId;
}
int Order::getOrderId() const {
  return orderId;
}
 void Order::setBuyer(int newBuyerId, string newBuyerName){
  buyer.setBuyerId(newBuyerId);
  buyer.setBuyerName(newBuyerName);
}

bool Order::addItem(const Food& item) {
  if (currentNum < 10) {
    orderedItems[currentNum++] = item;
    return true;
  } else {
    cout << "Order is full, cannot add more items.\n";
    return false; 
  }
}

void Order::displayOrder() const {
  double total = 0.0;

  cout << "Order Details:" << endl;
  cout << "Order ID: " << getOrderId() << ", ";

  // Access buyer details from the Buyer object
  const Buyer& buyer = getBuyer();
  cout << "Buyer ID: " << buyer.getBuyerId() << ", Name: " << buyer.getBuyerName() << endl;

  cout << "Items Ordered:" << endl;

  for (int i = 0; i < currentNum; ++i) {
    cout << "  - Item ID: " << orderedItems[i].getFoodId() << ", Name: "
              << orderedItems[i].getFoodName() << ", Price: $"
              << orderedItems[i].getPrice() << endl;
    total += orderedItems[i].getPrice();  // Calculate total price as each item is displayed
  }

  cout << "Total Bill: $" << total <<endl <<endl;
}

void Order::cloneOrder(const Order& other) {
  if (this != &other) {  // Check for self-assignment

    // Only copy currentNum
    currentNum = other.currentNum;

    // Since both orders have the same fixed capacity, we can directly copy items
    for (int i = 0; i < currentNum; ++i) {
      orderedItems[i] = other.orderedItems[i];
    }
  }
}
