#include "Food.h"

Food::Food(int id, const string& name, float price) : foodID(id), foodName(name), price(price) {}

Food::Food(const Food& other)
    : Food(other.foodID, other.foodName,other.price) {}

void Food::setFoodId(int newId) { 
    foodID = newId; 
}

int Food::getFoodId() const { 
    return foodID; 
}

void Food::setFoodName(const string& newName) { 
    foodName = newName; 
}

string Food::getFoodName() const { 
    return foodName; 
}

void Food::setPrice(float newPrice) { 
    price = newPrice; 
}

float Food::getPrice() const { 
    return price; 
}

