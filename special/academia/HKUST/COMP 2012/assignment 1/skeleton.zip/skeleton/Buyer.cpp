#include "Buyer.h"

// Task 1.1
Buyer::Buyer(int id, const string& name) {

}

// Task 1.2
void Buyer::setBuyerId(int newId) { 

}

// Task 1.3
int Buyer::getBuyerId() const {

}

// Task 1.4
void Buyer::setBuyerName(const string& newName) { 
 
}

// Task 1.5
string Buyer::getBuyerName() const { 

}
