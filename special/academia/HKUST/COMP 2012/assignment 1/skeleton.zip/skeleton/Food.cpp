#include "Food.h"

// Task 2.1
Food::Food(int id, const string& name, float price) {
}

// Task 2.2
Food::Food(const Food& other){

}

// Task 2.3
void Food::setFoodId(int newId) { 

}

// Task 2.4
int Food::getFoodId() const { 

}

// Task 2.5
void Food::setFoodName(const string& newName) { 

}

// Task 2.6
string Food::getFoodName() const { 

}

// Task 2.7
void Food::setPrice(float newPrice) { 
 
}

// Task 2.8
float Food::getPrice() const { 
 
}

