#include "RandomForest.h"

// TODO 2: 
// Take as input the test point x.
// Compute the predictions for every tree in the forest
// Find and return the majority label
int RandomForest::ForestPredict( int *x) { 
    int frequency[] = {0,0,0};
    
    for(int i = 0; i < NumberOfTrees; i++){
        frequency[Trees[i].TreePredict(x)]++;
    }
    if(frequency[0] >= frequency[1] && frequency[0] >= frequency[2]){
        return 0;
    }else if(frequency[1] >= frequency[2]){
        return 1;
    }else{
        return 2;
    }

}