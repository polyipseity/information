#include "RandomForest.h"

// TODO 2: 
// Take as input the test point x.
// Compute the predictions for every tree in the forest
// Find and return the majority label
int RandomForest::ForestPredict( int *x) { 
    // You can change this
    return 0;
}